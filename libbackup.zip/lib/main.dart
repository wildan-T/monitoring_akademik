import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:monitoring_akademik/core/theme/app_theme.dart';
import 'package:monitoring_akademik/core/constants/route_constants.dart';
import 'package:monitoring_akademik/presentation/providers/auth_provider.dart';
import 'package:monitoring_akademik/presentation/providers/siswa_provider.dart';
import 'package:monitoring_akademik/presentation/providers/guru_provider.dart';
import 'package:monitoring_akademik/presentation/providers/sekolah_provider.dart';
import 'package:monitoring_akademik/presentation/providers/nilai_provider.dart';
import 'package:monitoring_akademik/presentation/screens/splash/splash_screen.dart';
import 'package:monitoring_akademik/presentation/screens/auth/login_screen.dart';
import 'package:monitoring_akademik/presentation/screens/admin/admin_dashboard_screen.dart';
import 'package:monitoring_akademik/presentation/screens/guru/guru_dashboard_screen.dart';
import 'package:monitoring_akademik/presentation/screens/wali_murid/wali_murid_dashboard_screen.dart';
import 'package:monitoring_akademik/presentation/providers/user_provider.dart';
import 'package:monitoring_akademik/presentation/providers/absensi_provider.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => UserProvider()),
        ChangeNotifierProvider(create: (_) => GuruProvider()),
        ChangeNotifierProvider(create: (_) => SiswaProvider()),
        ChangeNotifierProvider(create: (_) => SekolahProvider()),
        ChangeNotifierProvider(create: (_) => NilaiProvider()),
        ChangeNotifierProvider(create: (_) => AbsensiProvider()),
      ],
      // ✅ UPDATE: Setup callbacks setelah providers ready
      builder: (context, child) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          final authProvider = Provider.of<AuthProvider>(context, listen: false);
          final userProvider = Provider.of<UserProvider>(context, listen: false);
          final guruProvider = Provider.of<GuruProvider>(context, listen: false);
          
          // Setup AuthProvider callback
          authProvider.setGetUsersCallback(() => userProvider.getAllUsers());
          
          // ✅ TAMBAH: Setup UserProvider dengan GuruProvider
          userProvider.setGuruProvider(guruProvider);
        });
        
        return child!;
      },
      child: MaterialApp(
        title: 'Monitoring Akademik',
        theme: AppTheme.lightTheme,
        debugShowCheckedModeBanner: false,
        initialRoute: RouteConstants.splash,
        routes: {
          RouteConstants.splash: (context) => const SplashScreen(),
          RouteConstants.login: (context) => const LoginScreen(),
          RouteConstants.adminDashboard: (context) => const AdminDashboardScreen(),
          RouteConstants.guruDashboard: (context) => const GuruDashboardScreen(),
          RouteConstants.waliMuridDashboard: (context) => const WaliMuridDashboardScreen(),
        },
      ),
    );
  }
}