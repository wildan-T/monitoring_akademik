import 'package:flutter/material.dart';
import '../../data/models/guru_model.dart';

class GuruProvider with ChangeNotifier {
  final List<GuruModel> _guruList = [
    GuruModel(
      id: '1',
      nama: 'Heni Rizki Amalia',
      nip: '197001012000122001',
      nuptk: '1234567890123456',
      email: 'heni.rizki@smpn20.sch.id',
      jenisKelamin: 'P',
      tempatLahir: 'Tangerang',
      tanggalLahir: DateTime(1985, 5, 15),
      agama: 'Islam',
      alamat: 'Jl. Merdeka No. 123, Tangerang',
      noTelp: '081234567890',
      pendidikanTerakhir: 'S1',
      waliKelas: '7A',
      mataPelajaran: ['Matematika', 'Bahasa Inggris', 'IPA'],
      status: 'Aktif',
      createdAt: DateTime.now(),
    ),
    GuruModel(
      id: '2',
      nama: 'Budi Prasetyo',
      nip: '198203102005011002',
      nuptk: '1234567890123457',
      email: 'Budiprasetyo@smpn20.sch.id',
      jenisKelamin: 'L',
      tempatLahir: 'Jakarta',
      tanggalLahir: DateTime(1982, 3, 10),
      agama: 'Islam',
      alamat: 'Jl. Sudirman No. 456, Tangerang',
      noTelp: '081234567891',
      pendidikanTerakhir: 'S2',
      waliKelas: '8B',
      mataPelajaran: ['Bahasa Indonesia', 'PKN'],
      status: 'Aktif',
      createdAt: DateTime.now(),
    ),
    GuruModel(
      id: '3',
      nama: 'Siti Nurhaliza',
      nip: '199001152010012003',
      nuptk: '1234567890123458',
      email: 'siti.nurhaliza@smpn20.sch.id',
      jenisKelamin: 'P',
      tempatLahir: 'Bandung',
      tanggalLahir: DateTime(1990, 1, 15),
      agama: 'Islam',
      alamat: 'Jl. Gatot Subroto No. 789, Tangerang',
      noTelp: '081234567892',
      pendidikanTerakhir: 'S1',
      waliKelas: null,
      mataPelajaran: ['Seni Budaya', 'Prakarya'],
      status: 'Aktif',
      createdAt: DateTime.now(),
    ),
  ];

  String? _errorMessage;
  bool _isLoading = false;

  // Filter variables
  String _searchQuery = '';
  String _filterMataPelajaran = 'Semua';
  String _filterStatus = 'Semua';

  // Getters
  List<GuruModel> get guruList => _guruList;
  String? get errorMessage => _errorMessage;
  bool get isLoading => _isLoading;
  
  String get filterMataPelajaran => _filterMataPelajaran;
  String get filterStatus => _filterStatus;

  // Daftar wali kelas yang sudah dipakai
  List<String> get usedWaliKelas {
    return _guruList
        .where((guru) => guru.waliKelas != null && guru.waliKelas!.isNotEmpty)
        .map((guru) => guru.waliKelas!)
        .toList();
  }

  // Get guru by ID
  GuruModel? getGuruById(String id) {
    try {
      return _guruList.firstWhere((guru) => guru.id == id);
    } catch (e) {
      return null;
    }
  }

  // Get filtered guru list
  List<GuruModel> getFilteredGuruList() {
    var filtered = _guruList;

    // Filter by search query
    if (_searchQuery.isNotEmpty) {
      filtered = filtered.where((guru) {
        return guru.nama.toLowerCase().contains(_searchQuery.toLowerCase()) ||
            guru.nip.toLowerCase().contains(_searchQuery.toLowerCase());
      }).toList();
    }

    // Filter by mata pelajaran
    if (_filterMataPelajaran.isNotEmpty && _filterMataPelajaran != 'Semua') {
      filtered = filtered.where((guru) {
        return guru.mataPelajaran.contains(_filterMataPelajaran);
      }).toList();
    }

    // Filter by status
    if (_filterStatus.isNotEmpty && _filterStatus != 'Semua') {
      filtered = filtered.where((guru) => guru.status == _filterStatus).toList();
    }

    return filtered;
  }

  // Set filters
  void setSearchQuery(String query) {
    _searchQuery = query;
    notifyListeners();
  }

  void setFilterMataPelajaran(String mataPelajaran) {
    _filterMataPelajaran = mataPelajaran;
    notifyListeners();
  }

  void setFilterStatus(String status) {
    _filterStatus = status;
    notifyListeners();
  }

  void clearFilters() {
    _searchQuery = '';
    _filterMataPelajaran = 'Semua';
    _filterStatus = 'Semua';
    notifyListeners();
  }

  // ✅ ADD GURU dengan DEBUG LOG
  Future<bool> addGuru(GuruModel guru) async {
    print('🎓 GuruProvider.addGuru() DIPANGGIL'); // ✅ DEBUG
    print('📝 ID: ${guru.id}'); // ✅ DEBUG
    print('📝 Nama: ${guru.nama}'); // ✅ DEBUG
    print('📝 Email: ${guru.email}'); // ✅ DEBUG
    print('📊 Total guru SEBELUM add: ${_guruList.length}'); // ✅ DEBUG
    
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      await Future.delayed(const Duration(seconds: 1));
      
      _guruList.add(guru);
      
      print('✅ Guru berhasil ditambahkan ke _guruList'); // ✅ DEBUG
      print('📊 Total guru SETELAH add: ${_guruList.length}'); // ✅ DEBUG
      print('📋 List nama guru: ${_guruList.map((g) => g.nama).toList()}'); // ✅ DEBUG
      
      _isLoading = false;
      notifyListeners();
      
      print('✅ notifyListeners() DIPANGGIL'); // ✅ DEBUG
      
      return true;
    } catch (e) {
      print('❌ ERROR addGuru: $e'); // ✅ DEBUG
      _errorMessage = 'Gagal menambahkan guru: ${e.toString()}';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // ✅ UPDATE GURU dengan DEBUG LOG
  Future<bool> updateGuru(GuruModel guru) async {
    print('🔄 GuruProvider.updateGuru() DIPANGGIL'); // ✅ DEBUG
    print('📝 ID: ${guru.id}'); // ✅ DEBUG
    print('📝 Nama: ${guru.nama}'); // ✅ DEBUG
    
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      await Future.delayed(const Duration(seconds: 1));
      
      final index = _guruList.indexWhere((g) => g.id == guru.id);
      
      if (index != -1) {
        print('✅ Guru ditemukan di index: $index'); // ✅ DEBUG
        _guruList[index] = guru;
        print('✅ Guru berhasil diupdate'); // ✅ DEBUG
      } else {
        print('❌ Guru TIDAK DITEMUKAN dengan ID: ${guru.id}'); // ✅ DEBUG
      }
      
      _isLoading = false;
      notifyListeners();
      
      print('✅ notifyListeners() DIPANGGIL'); // ✅ DEBUG
      
      return true;
    } catch (e) {
      print('❌ ERROR updateGuru: $e'); // ✅ DEBUG
      _errorMessage = 'Gagal mengupdate guru: ${e.toString()}';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // ✅ DELETE GURU dengan DEBUG LOG
  Future<bool> deleteGuru(String id) async {
    print('🗑️ GuruProvider.deleteGuru() DIPANGGIL'); // ✅ DEBUG
    print('📝 ID yang akan dihapus: $id'); // ✅ DEBUG
    print('📊 Total guru SEBELUM delete: ${_guruList.length}'); // ✅ DEBUG
    
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      await Future.delayed(const Duration(seconds: 1));
      
      _guruList.removeWhere((guru) => guru.id == id);
      
      print('✅ Guru berhasil dihapus'); // ✅ DEBUG
      print('📊 Total guru SETELAH delete: ${_guruList.length}'); // ✅ DEBUG
      
      _isLoading = false;
      notifyListeners();
      
      print('✅ notifyListeners() DIPANGGIL'); // ✅ DEBUG
      
      return true;
    } catch (e) {
      print('❌ ERROR deleteGuru: $e'); // ✅ DEBUG
      _errorMessage = 'Gagal menghapus guru: ${e.toString()}';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }
}