//C:\Users\MSITHIN\monitoring_akademik\lib\presentation\providers\nilai_provider.dart
import 'package:flutter/material.dart';
import '../../data/models/nilai_model.dart';
import '../../data/models/kelas_mapel_model.dart';
import '../../data/models/statistik_nilai_model.dart';

class NilaiProvider with ChangeNotifier {
  // ✅ Kelas & mapel yang diajar oleh 3 guru
  final List<KelasMapelModel> _kelasMapelList = [
    // GURU 1: Heni Rizki Amalia (Wali Kelas 7A)
    KelasMapelModel(
      id: '1',
      guruId: '1',
      kelas: '7A',
      mataPelajaran: 'Matematika',
    ),
    KelasMapelModel(
      id: '2',
      guruId: '1',
      kelas: '7A',
      mataPelajaran: 'IPA',
    ),
    
    // GURU 2: Ahmad Fauzi (Wali Kelas 7B)
    KelasMapelModel(
      id: '3',
      guruId: '2',
      kelas: '7B',
      mataPelajaran: 'Matematika',
    ),
    KelasMapelModel(
      id: '4',
      guruId: '2',
      kelas: '7B',
      mataPelajaran: 'IPA',
    ),
    
    // GURU 3: Siti Aminah (Guru Mapel - BUKAN Wali Kelas)
    KelasMapelModel(
      id: '5',
      guruId: '3',
      kelas: '7A',
      mataPelajaran: 'Bahasa Indonesia',
    ),
    KelasMapelModel(
      id: '6',
      guruId: '3',
      kelas: '7B',
      mataPelajaran: 'Bahasa Inggris',
    ),
  ];

  // ✅ DATA NILAI DUMMY (15 data) - UPDATED dengan namaSiswa & kelas
  final List<NilaiModel> _nilaiList = [
    // ==========================================
    // GURU 1: HENI RIZKI AMALIA (Wali Kelas 7A)
    // ==========================================
    
    // Matematika 7A - Siswa 1 (Andi)
    NilaiModel(
      id: '1',
      siswaId: '1',
      namaSiswa: 'Andi Wijaya',
      guruId: '1',
      kelasId: '7A',
      kelas: '7A',
      mataPelajaran: 'Matematika',
      nilaiTugas: 85,
      nilaiUH: 80,
      nilaiUTS: 78,
      nilaiUAS: 82,
      nilaiPraktik: null,
      nilaiSikap: 'B',
      isFinalized: true,
      finalizedAt: DateTime(2024, 12, 20),
      finalizedBy: '1',
      createdAt: DateTime(2024, 9, 15),
      updatedAt: DateTime(2024, 12, 20),
    ),
    
    // Matematika 7A - Siswa 2 (Budi)
    NilaiModel(
      id: '2',
      siswaId: '2',
      namaSiswa: 'Budi Santoso',
      guruId: '1',
      kelasId: '7A',
      kelas: '7A',
      mataPelajaran: 'Matematika',
      nilaiTugas: 90,
      nilaiUH: 88,
      nilaiUTS: 85,
      nilaiUAS: 88,
      nilaiPraktik: null,
      nilaiSikap: 'A',
      isFinalized: true,
      finalizedAt: DateTime(2024, 12, 20),
      finalizedBy: '1',
      createdAt: DateTime(2024, 9, 15),
      updatedAt: DateTime(2024, 12, 20),
    ),
    
    // Matematika 7A - Siswa 3 (Citra)
    NilaiModel(
      id: '3',
      siswaId: '3',
      namaSiswa: 'Citra Dewi',
      guruId: '1',
      kelasId: '7A',
      kelas: '7A',
      mataPelajaran: 'Matematika',
      nilaiTugas: 88,
      nilaiUH: 82,
      nilaiUTS: 80,
      nilaiUAS: 85,
      nilaiPraktik: null,
      nilaiSikap: 'B',
      isFinalized: true,
      finalizedAt: DateTime(2024, 12, 20),
      finalizedBy: '1',
      createdAt: DateTime(2024, 9, 15),
      updatedAt: DateTime(2024, 12, 20),
    ),

    // IPA 7A - Siswa 1 (Andi)
    NilaiModel(
      id: '4',
      siswaId: '1',
      namaSiswa: 'Andi Wijaya',
      guruId: '1',
      kelasId: '7A',
      kelas: '7A',
      mataPelajaran: 'IPA',
      nilaiTugas: 80,
      nilaiUH: 78,
      nilaiUTS: 75,
      nilaiUAS: 78,
      nilaiPraktik: 85,
      nilaiSikap: 'B',
      isFinalized: true,
      finalizedAt: DateTime(2024, 12, 20),
      finalizedBy: '1',
      createdAt: DateTime(2024, 9, 15),
      updatedAt: DateTime(2024, 12, 20),
    ),

    // IPA 7A - Siswa 2 (Budi)
    NilaiModel(
      id: '5',
      siswaId: '2',
      namaSiswa: 'Budi Santoso',
      guruId: '1',
      kelasId: '7A',
      kelas: '7A',
      mataPelajaran: 'IPA',
      nilaiTugas: 85,
      nilaiUH: 83,
      nilaiUTS: 82,
      nilaiUAS: 84,
      nilaiPraktik: 88,
      nilaiSikap: 'A',
      isFinalized: true,
      finalizedAt: DateTime(2024, 12, 20),
      finalizedBy: '1',
      createdAt: DateTime(2024, 9, 15),
      updatedAt: DateTime(2024, 12, 20),
    ),

    // IPA 7A - Siswa 3 (Citra)
    NilaiModel(
      id: '6',
      siswaId: '3',
      namaSiswa: 'Citra Dewi',
      guruId: '1',
      kelasId: '7A',
      kelas: '7A',
      mataPelajaran: 'IPA',
      nilaiTugas: 90,
      nilaiUH: 87,
      nilaiUTS: 88,
      nilaiUAS: 89,
      nilaiPraktik: 92,
      nilaiSikap: 'A',
      isFinalized: true,
      finalizedAt: DateTime(2024, 12, 20),
      finalizedBy: '1',
      createdAt: DateTime(2024, 9, 15),
      updatedAt: DateTime(2024, 12, 20),
    ),

    // ==========================================
    // GURU 2: AHMAD FAUZI (Wali Kelas 7B)
    // ==========================================
    
    // Matematika 7B - Siswa 4 (Dani)
    NilaiModel(
      id: '7',
      siswaId: '4',
      namaSiswa: 'Dani Pratama',
      guruId: '2',
      kelasId: '7B',
      kelas: '7B',
      mataPelajaran: 'Matematika',
      nilaiTugas: 88,
      nilaiUH: 85,
      nilaiUTS: 82,
      nilaiUAS: 85,
      nilaiPraktik: null,
      nilaiSikap: 'B',
      isFinalized: true,
      finalizedAt: DateTime(2024, 12, 20),
      finalizedBy: '2',
      createdAt: DateTime(2024, 9, 15),
      updatedAt: DateTime(2024, 12, 20),
    ),

    // Matematika 7B - Siswa 5 (Eka)
    NilaiModel(
      id: '8',
      siswaId: '5',
      namaSiswa: 'Eka Putri',
      guruId: '2',
      kelasId: '7B',
      kelas: '7B',
      mataPelajaran: 'Matematika',
      nilaiTugas: 92,
      nilaiUH: 90,
      nilaiUTS: 88,
      nilaiUAS: 90,
      nilaiPraktik: null,
      nilaiSikap: 'A',
      isFinalized: true,
      finalizedAt: DateTime(2024, 12, 20),
      finalizedBy: '2',
      createdAt: DateTime(2024, 9, 15),
      updatedAt: DateTime(2024, 12, 20),
    ),

    // IPA 7B - Siswa 4 (Dani)
    NilaiModel(
      id: '9',
      siswaId: '4',
      namaSiswa: 'Dani Pratama',
      guruId: '2',
      kelasId: '7B',
      kelas: '7B',
      mataPelajaran: 'IPA',
      nilaiTugas: 85,
      nilaiUH: 82,
      nilaiUTS: 80,
      nilaiUAS: 83,
      nilaiPraktik: 87,
      nilaiSikap: 'B',
      isFinalized: true,
      finalizedAt: DateTime(2024, 12, 20),
      finalizedBy: '2',
      createdAt: DateTime(2024, 9, 15),
      updatedAt: DateTime(2024, 12, 20),
    ),

    // IPA 7B - Siswa 5 (Eka)
    NilaiModel(
      id: '10',
      siswaId: '5',
      namaSiswa: 'Eka Putri',
      guruId: '2',
      kelasId: '7B',
      kelas: '7B',
      mataPelajaran: 'IPA',
      nilaiTugas: 90,
      nilaiUH: 88,
      nilaiUTS: 85,
      nilaiUAS: 88,
      nilaiPraktik: 90,
      nilaiSikap: 'A',
      isFinalized: true,
      finalizedAt: DateTime(2024, 12, 20),
      finalizedBy: '2',
      createdAt: DateTime(2024, 9, 15),
      updatedAt: DateTime(2024, 12, 20),
    ),

    // ==========================================
    // GURU 3: SITI AMINAH (Guru Mapel - BUKAN Wali Kelas)
    // ==========================================
    
    // Bahasa Indonesia 7A - Siswa 1 (Andi)
    NilaiModel(
      id: '11',
      siswaId: '1',
      namaSiswa: 'Andi Wijaya',
      guruId: '3',
      kelasId: '7A',
      kelas: '7A',
      mataPelajaran: 'Bahasa Indonesia',
      nilaiTugas: 85,
      nilaiUH: 83,
      nilaiUTS: 82,
      nilaiUAS: 84,
      nilaiPraktik: null,
      nilaiSikap: 'B',
      isFinalized: false,
      createdAt: DateTime(2024, 9, 15),
      updatedAt: DateTime(2024, 12, 18),
    ),

    // Bahasa Indonesia 7A - Siswa 2 (Budi)
    NilaiModel(
      id: '12',
      siswaId: '2',
      namaSiswa: 'Budi Santoso',
      guruId: '3',
      kelasId: '7A',
      kelas: '7A',
      mataPelajaran: 'Bahasa Indonesia',
      nilaiTugas: 90,
      nilaiUH: 88,
      nilaiUTS: 88,
      nilaiUAS: 89,
      nilaiPraktik: null,
      nilaiSikap: 'A',
      isFinalized: false,
      createdAt: DateTime(2024, 9, 15),
      updatedAt: DateTime(2024, 12, 18),
    ),

    // Bahasa Indonesia 7A - Siswa 3 (Citra)
    NilaiModel(
      id: '13',
      siswaId: '3',
      namaSiswa: 'Citra Dewi',
      guruId: '3',
      kelasId: '7A',
      kelas: '7A',
      mataPelajaran: 'Bahasa Indonesia',
      nilaiTugas: 88,
      nilaiUH: 86,
      nilaiUTS: 85,
      nilaiUAS: 87,
      nilaiPraktik: null,
      nilaiSikap: 'B',
      isFinalized: false,
      createdAt: DateTime(2024, 9, 15),
      updatedAt: DateTime(2024, 12, 18),
    ),

    // Bahasa Inggris 7B - Siswa 4 (Dani)
    NilaiModel(
      id: '14',
      siswaId: '4',
      namaSiswa: 'Dani Pratama',
      guruId: '3',
      kelasId: '7B',
      kelas: '7B',
      mataPelajaran: 'Bahasa Inggris',
      nilaiTugas: 82,
      nilaiUH: 80,
      nilaiUTS: 78,
      nilaiUAS: 80,
      nilaiPraktik: null,
      nilaiSikap: 'B',
      isFinalized: false,
      createdAt: DateTime(2024, 9, 15),
      updatedAt: DateTime(2024, 12, 18),
    ),

    // Bahasa Inggris 7B - Siswa 5 (Eka)
    NilaiModel(
      id: '15',
      siswaId: '5',
      namaSiswa: 'Eka Putri',
      guruId: '3',
      kelasId: '7B',
      kelas: '7B',
      mataPelajaran: 'Bahasa Inggris',
      nilaiTugas: 88,
      nilaiUH: 86,
      nilaiUTS: 85,
      nilaiUAS: 87,
      nilaiPraktik: null,
      nilaiSikap: 'A',
      isFinalized: false,
      createdAt: DateTime(2024, 9, 15),
      updatedAt: DateTime(2024, 12, 18),
    ),
  ];

  bool _isLoading = false;
  String? _errorMessage;

  // Getters
  List<KelasMapelModel> get kelasMapelList => _kelasMapelList;
  List<NilaiModel> get nilaiList => _nilaiList;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  // ✅ GET ALL NILAI (untuk admin)
  List<NilaiModel> getAllNilai() {
    print('📊 NilaiProvider.getAllNilai() DIPANGGIL');
    print('📊 Total nilai: ${_nilaiList.length}');
    return List.from(_nilaiList); // Return copy
  }

  // Get kelas mapel by guru ID
  List<KelasMapelModel> getKelasMapelByGuruId(String guruId) {
    return _kelasMapelList.where((km) => km.guruId == guruId).toList();
  }

  // Get semua mapel di kelas tertentu (untuk wali kelas)
  List<KelasMapelModel> getKelasMapelByKelas(String kelas) {
    return _kelasMapelList.where((km) => km.kelas == kelas).toList();
  }

  // Get nilai by siswa, kelas, mapel
  NilaiModel? getNilai({
    required String siswaId,
    required String kelas,
    required String mataPelajaran,
  }) {
    try {
      return _nilaiList.firstWhere(
        (nilai) =>
            nilai.siswaId == siswaId &&
            nilai.kelasId == kelas &&
            nilai.mataPelajaran == mataPelajaran,
      );
    } catch (e) {
      return null;
    }
  }

  // Get all nilai by kelas & mapel
  List<NilaiModel> getNilaiByKelasMapel({
    required String kelas,
    required String mataPelajaran,
  }) {
    return _nilaiList
        .where((nilai) =>
            nilai.kelasId == kelas && nilai.mataPelajaran == mataPelajaran)
        .toList();
  }

  // Add or Update Nilai
  Future<bool> saveNilai({
    required String siswaId,
    required String guruId,
    required String kelas,
    required String mataPelajaran,
    required double? nilaiTugas,
    required double? nilaiUH,
    required double? nilaiUTS,
    required double? nilaiUAS,
    required double? nilaiPraktik,
    required String? nilaiSikap,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      // Simulasi delay network
      await Future.delayed(const Duration(seconds: 1));

      // Cek apakah nilai sudah difinalisasi
      final existingNilai = getNilai(
        siswaId: siswaId,
        kelas: kelas,
        mataPelajaran: mataPelajaran,
      );

      // Tidak bisa update jika sudah difinalisasi
      if (existingNilai != null && existingNilai.isFinalized) {
        _errorMessage = 'Nilai sudah difinalisasi dan tidak dapat diubah';
        _isLoading = false;
        notifyListeners();
        return false;
      }

      if (existingNilai != null) {
        // Update nilai existing
        final index = _nilaiList.indexWhere((n) => n.id == existingNilai.id);
        _nilaiList[index] = existingNilai.copyWith(
          nilaiTugas: nilaiTugas,
          nilaiUH: nilaiUH,
          nilaiUTS: nilaiUTS,
          nilaiUAS: nilaiUAS,
          nilaiPraktik: nilaiPraktik,
          nilaiSikap: nilaiSikap,
          updatedAt: DateTime.now(),
        );
      } else {
        // Tambah nilai baru (need to get siswa name from SiswaProvider)
        // For now, use placeholder
        final newNilai = NilaiModel(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          siswaId: siswaId,
          namaSiswa: 'Siswa Baru', // TODO: Get from SiswaProvider
          guruId: guruId,
          kelasId: kelas,
          kelas: kelas,
          mataPelajaran: mataPelajaran,
          nilaiTugas: nilaiTugas,
          nilaiUH: nilaiUH,
          nilaiUTS: nilaiUTS,
          nilaiUAS: nilaiUAS,
          nilaiPraktik: nilaiPraktik,
          nilaiSikap: nilaiSikap,
          createdAt: DateTime.now(),
        );
        _nilaiList.add(newNilai);
      }

      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _errorMessage = 'Gagal menyimpan nilai: ${e.toString()}';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // ✅ UPDATE NILAI
  Future<bool> updateNilai(NilaiModel nilai) async {
    print('🔄 NilaiProvider.updateNilai() DIPANGGIL');
    print('📝 ID: ${nilai.id}');
    print('📝 Siswa: ${nilai.namaSiswa}');
    print('📝 Mapel: ${nilai.mataPelajaran}');
    
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      await Future.delayed(const Duration(seconds: 1));
      
      final index = _nilaiList.indexWhere((n) => n.id == nilai.id);
      
      if (index != -1) {
        print('✅ Nilai ditemukan di index: $index');
        _nilaiList[index] = nilai;
        print('✅ Nilai berhasil diupdate');
        print('✅ Nilai Akhir: ${nilai.nilaiAkhir?.toStringAsFixed(1)}');
      } else {
        print('❌ Nilai TIDAK DITEMUKAN dengan ID: ${nilai.id}');
      }
      
      _isLoading = false;
      notifyListeners();
      
      print('✅ notifyListeners() DIPANGGIL');
      
      return true;
    } catch (e) {
      print('❌ ERROR updateNilai: $e');
      _errorMessage = 'Gagal mengupdate nilai: ${e.toString()}';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // ✅ DELETE NILAI
  Future<bool> deleteNilai(String id) async {
    print('🗑️ NilaiProvider.deleteNilai() DIPANGGIL');
    print('📝 ID yang akan dihapus: $id');
    print('📊 Total nilai SEBELUM delete: ${_nilaiList.length}');
    
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      // Cek apakah nilai sudah difinalisasi
      final nilai = _nilaiList.firstWhere((n) => n.id == id);
      if (nilai.isFinalized) {
        _errorMessage = 'Nilai sudah difinalisasi dan tidak dapat dihapus';
        _isLoading = false;
        notifyListeners();
        return false;
      }

      await Future.delayed(const Duration(seconds: 1));
      _nilaiList.removeWhere((nilai) => nilai.id == id);
      
      print('✅ Nilai berhasil dihapus');
      print('📊 Total nilai SETELAH delete: ${_nilaiList.length}');
      
      _isLoading = false;
      notifyListeners();
      
      print('✅ notifyListeners() DIPANGGIL');
      
      return true;
    } catch (e) {
      print('❌ ERROR deleteNilai: $e');
      _errorMessage = 'Gagal menghapus nilai: ${e.toString()}';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // Get statistik nilai per kelas & mapel
  Map<String, dynamic> getStatistik({
    required String kelas,
    required String mataPelajaran,
  }) {
    final nilaiList = getNilaiByKelasMapel(
      kelas: kelas,
      mataPelajaran: mataPelajaran,
    );

    if (nilaiList.isEmpty) {
      return {
        'total_siswa': 0,
        'sudah_dinilai': 0,
        'belum_dinilai': 0,
        'rata_rata': 0.0,
      };
    }

    final sudahDinilai = nilaiList.where((n) => n.isComplete).length;
    final nilaiAkhirList = nilaiList
        .where((n) => n.nilaiAkhir != null)
        .map((n) => n.nilaiAkhir!)
        .toList();

    final rataRata = nilaiAkhirList.isEmpty
        ? 0.0
        : nilaiAkhirList.reduce((a, b) => a + b) / nilaiAkhirList.length;

    return {
      'total_siswa': nilaiList.length,
      'sudah_dinilai': sudahDinilai,
      'belum_dinilai': nilaiList.length - sudahDinilai,
      'rata_rata': rataRata,
    };
  }

  // Get statistik detail untuk rekap nilai
  StatistikNilaiModel getStatistikDetail({
    required String kelas,
    required String mataPelajaran,
  }) {
    final nilaiList = getNilaiByKelasMapel(
      kelas: kelas,
      mataPelajaran: mataPelajaran,
    );

    if (nilaiList.isEmpty) {
      return StatistikNilaiModel(
        kelas: kelas,
        mataPelajaran: mataPelajaran,
        totalSiswa: 0,
        sudahDinilai: 0,
        belumDinilai: 0,
        rataRata: 0,
        nilaiTertinggi: 0,
        nilaiTerendah: 0,
        jumlahA: 0,
        jumlahB: 0,
        jumlahC: 0,
        jumlahD: 0,
        jumlahE: 0,
      );
    }

    final sudahDinilai = nilaiList.where((n) => n.isComplete).length;
    final nilaiAkhirList = nilaiList
        .where((n) => n.nilaiAkhir != null)
        .map((n) => n.nilaiAkhir!)
        .toList();

    final rataRata = nilaiAkhirList.isEmpty
        ? 0.0
        : nilaiAkhirList.reduce((a, b) => a + b) / nilaiAkhirList.length;

    final nilaiTertinggi = nilaiAkhirList.isEmpty
        ? 0.0
        : nilaiAkhirList.reduce((a, b) => a > b ? a : b);

    final nilaiTerendah = nilaiAkhirList.isEmpty
        ? 0.0
        : nilaiAkhirList.reduce((a, b) => a < b ? a : b);

    // Hitung jumlah per grade
    int jumlahA = 0, jumlahB = 0, jumlahC = 0, jumlahD = 0, jumlahE = 0;
    for (var nilai in nilaiList) {
      if (nilai.nilaiHuruf == 'A') jumlahA++;
      if (nilai.nilaiHuruf == 'B') jumlahB++;
      if (nilai.nilaiHuruf == 'C') jumlahC++;
      if (nilai.nilaiHuruf == 'D') jumlahD++;
      if (nilai.nilaiHuruf == 'E') jumlahE++;
    }

    return StatistikNilaiModel(
      kelas: kelas,
      mataPelajaran: mataPelajaran,
      totalSiswa: nilaiList.length,
      sudahDinilai: sudahDinilai,
      belumDinilai: nilaiList.length - sudahDinilai,
      rataRata: rataRata,
      nilaiTertinggi: nilaiTertinggi,
      nilaiTerendah: nilaiTerendah,
      jumlahA: jumlahA,
      jumlahB: jumlahB,
      jumlahC: jumlahC,
      jumlahD: jumlahD,
      jumlahE: jumlahE,
    );
  }

  // Finalisasi nilai (hanya bisa dilakukan Wali Kelas)
  Future<bool> finalisasiNilai({
    required String kelas,
    required String mataPelajaran,
    required String waliKelasId,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      await Future.delayed(const Duration(seconds: 1));

      // Update semua nilai yang sudah lengkap di kelas & mapel ini
      for (int i = 0; i < _nilaiList.length; i++) {
        if (_nilaiList[i].kelasId == kelas &&
            _nilaiList[i].mataPelajaran == mataPelajaran &&
            _nilaiList[i].isComplete &&
            !_nilaiList[i].isFinalized) {
          _nilaiList[i] = _nilaiList[i].copyWith(
            isFinalized: true,
            finalizedAt: DateTime.now(),
            finalizedBy: waliKelasId,
          );
        }
      }

      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _errorMessage = 'Gagal finalisasi nilai: ${e.toString()}';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // Cek apakah nilai sudah difinalisasi
  bool isNilaiFinalized({
    required String kelas,
    required String mataPelajaran,
  }) {
    final nilaiList = getNilaiByKelasMapel(
      kelas: kelas,
      mataPelajaran: mataPelajaran,
    );

    if (nilaiList.isEmpty) return false;

    // Jika ada minimal 1 nilai yang finalized, return true
    return nilaiList.any((n) => n.isFinalized);
  }
}