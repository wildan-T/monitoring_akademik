//C:\Users\MSITHIN\monitoring_akademik\lib\presentation\providers\user_provider.dart
import 'package:flutter/foundation.dart';
import '../../data/models/user_model.dart';
import '../../core/constants/app_constants.dart';
import '../../data/models/guru_model.dart';
import 'guru_provider.dart';

class UserProvider with ChangeNotifier {
  List<UserModel> _users = [];
  List<UserModel> _filteredUsers = [];
  bool _isLoading = false;
  String? _errorMessage;
  String _selectedRole = 'all'; // all, admin, guru, wali_murid
  
  // ✅ Reference ke GuruProvider
  GuruProvider? _guruProvider;

  // Getters
  List<UserModel> get users => _filteredUsers;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  String get selectedRole => _selectedRole;

  UserProvider() {
    _initDummyData();
  }

  // ✅ Method untuk inject GuruProvider
  void setGuruProvider(GuruProvider guruProvider) {
    _guruProvider = guruProvider;
  }

  // ✅ SYNC DENGAN APP_CONSTANTS
  void _initDummyData() {
    _users = [
      // Admin
      UserModel(
        id: AppConstants.dummyAdmin['id'],
        username: AppConstants.dummyAdmin['username'],
        name: AppConstants.dummyAdmin['name'],
        role: AppConstants.dummyAdmin['role'],
        email: AppConstants.dummyAdmin['email'],
        phone: null,
      ),
      
      // Guru 1 - Heni Rizki Amalia
      UserModel(
        id: AppConstants.dummyGuru['id'],
        username: AppConstants.dummyGuru['username'],
        name: AppConstants.dummyGuru['name'],
        role: AppConstants.dummyGuru['role'],
        email: AppConstants.dummyGuru['email'],
        phone: null,
      ),
      
      // Guru 2 - Budi Prasetyo
      UserModel(
        id: AppConstants.dummyGuru2['id'],
        username: AppConstants.dummyGuru2['username'],
        name: AppConstants.dummyGuru2['name'],
        role: AppConstants.dummyGuru2['role'],
        email: AppConstants.dummyGuru2['email'],
        phone: null,
      ),
      
      // Guru 3 - Siti Aminah
      UserModel(
        id: AppConstants.dummyGuru3['id'],
        username: AppConstants.dummyGuru3['username'],
        name: AppConstants.dummyGuru3['name'],
        role: AppConstants.dummyGuru3['role'],
        email: null,
        phone: null,
      ),
      
      // Wali Murid
      UserModel(
        id: AppConstants.dummyWaliMurid['id'],
        username: AppConstants.dummyWaliMurid['username'],
        name: AppConstants.dummyWaliMurid['name'],
        role: AppConstants.dummyWaliMurid['role'],
        email: AppConstants.dummyWaliMurid['email'],
        phone: null,
      ),
    ];
    
    _filteredUsers = List.from(_users);
    
    // ✅ DEBUG LOG
    print('📦 UserProvider initialized dengan ${_users.length} users');
  }

  // Filter by Role
  void filterByRole(String role) {
    _selectedRole = role;
    
    if (role == 'all') {
      _filteredUsers = List.from(_users);
    } else {
      _filteredUsers = _users.where((user) => user.role == role).toList();
    }
    
    notifyListeners();
  }

  // Search User
  void searchUser(String query) {
    if (query.isEmpty) {
      filterByRole(_selectedRole);
      return;
    }
    
    _filteredUsers = _users.where((user) {
      final matchesRole = _selectedRole == 'all' || user.role == _selectedRole;
      final matchesQuery = user.name.toLowerCase().contains(query.toLowerCase()) ||
                          (user.email?.toLowerCase().contains(query.toLowerCase()) ?? false) ||
                          user.username.toLowerCase().contains(query.toLowerCase());
      
      return matchesRole && matchesQuery;
    }).toList();
    
    notifyListeners();
  }

  // ✅ ADD USER dengan auto-create guru + DEBUG LOG
  Future<bool> addUser(UserModel user) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    await Future.delayed(const Duration(seconds: 1)); // Simulasi network

    try {
      // Validasi email duplicate
      if (user.email != null && _users.any((u) => u.email == user.email)) {
        _errorMessage = 'Email sudah digunakan';
        _isLoading = false;
        notifyListeners();
        return false;
      }

      // Validasi username duplicate
      if (_users.any((u) => u.username == user.username)) {
        _errorMessage = 'Username sudah digunakan';
        _isLoading = false;
        notifyListeners();
        return false;
      }

      // Generate ID
      final userId = DateTime.now().millisecondsSinceEpoch.toString();
      final newUser = UserModel(
        id: userId,
        username: user.username,
        name: user.name,
        role: user.role,
        email: user.email,
        phone: user.phone,
      );

      _users.add(newUser);
      
      // ✅ DEBUG LOG
      print('✅ User berhasil ditambahkan: ${newUser.username}');
      print('📊 Total users sekarang: ${_users.length}');
      print('📋 List username: ${_users.map((u) => u.username).toList()}');
      
      // ✅ Auto-create data guru jika role = guru
      if (user.role == AppConstants.roleGuru && _guruProvider != null) {
        print('🎓 Creating guru data for: ${user.name}');
        
        final now = DateTime.now();
        final guruModel = GuruModel(
          id: userId, // ✅ Sama dengan user ID
          nama: user.name,
          nip: '', // ✅ Kosong, admin edit nanti
          nuptk: null, // ✅ Kosong
          email: user.email ?? '', // ✅ Dari user atau default empty
          jenisKelamin: 'L', // ✅ Default Laki-laki
          tempatLahir: 'Belum diisi', // ✅ Default
          tanggalLahir: DateTime(1990, 1, 1), // ✅ Default 1 Jan 1990
          agama: 'Islam', // ✅ Default
          alamat: 'Belum diisi', // ✅ Default
          noTelp: user.phone ?? '', // ✅ Dari user atau empty
          pendidikanTerakhir: 'S1', // ✅ Default S1
          waliKelas: null, // ✅ Belum wali kelas
          mataPelajaran: ['Belum ditentukan'], // ✅ Default list
          status: 'Aktif', // ✅ Default aktif
          createdAt: now,
          updatedAt: null,
        );
        
        await _guruProvider!.addGuru(guruModel);
        print('✅ Guru data created successfully');
      }
      
      filterByRole(_selectedRole); // Refresh filtered list
      
      _isLoading = false;
      notifyListeners();
      return true;
      
    } catch (e) {
      print('❌ Error addUser: $e');
      _errorMessage = 'Gagal menambah user: $e';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // ✅ UPDATE USER dengan auto-sync guru
  Future<bool> updateUser(UserModel user) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    await Future.delayed(const Duration(seconds: 1)); // Simulasi network

    try {
      final index = _users.indexWhere((u) => u.id == user.id);
      
      if (index == -1) {
        _errorMessage = 'User tidak ditemukan';
        _isLoading = false;
        notifyListeners();
        return false;
      }

      // Validasi email duplicate (kecuali email sendiri)
      if (user.email != null && _users.any((u) => u.email == user.email && u.id != user.id)) {
        _errorMessage = 'Email sudah digunakan';
        _isLoading = false;
        notifyListeners();
        return false;
      }

      // Validasi username duplicate (kecuali username sendiri)
      if (_users.any((u) => u.username == user.username && u.id != user.id)) {
        _errorMessage = 'Username sudah digunakan';
        _isLoading = false;
        notifyListeners();
        return false;
      }

      _users[index] = user;
      
      // ✅ DEBUG LOG
      print('✅ User updated: ${user.username}');
      
      // ✅ Auto-update data guru jika role = guru
      if (user.role == AppConstants.roleGuru && _guruProvider != null) {
        final guru = _guruProvider!.getGuruById(user.id);
        if (guru != null) {
          // Update nama, email, dan telepon guru saja (field lain tetap)
          final updatedGuru = guru.copyWith(
            nama: user.name,
            email: user.email ?? guru.email,
            noTelp: user.phone ?? guru.noTelp,
            updatedAt: DateTime.now(),
          );
          await _guruProvider!.updateGuru(updatedGuru);
          print('✅ Guru data synced');
        }
      }
      
      filterByRole(_selectedRole); // Refresh filtered list
      
      _isLoading = false;
      notifyListeners();
      return true;
      
    } catch (e) {
      print('❌ Error updateUser: $e');
      _errorMessage = 'Gagal mengupdate user: $e';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // ✅ DELETE USER dengan auto-delete guru
  Future<bool> deleteUser(String userId) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    await Future.delayed(const Duration(milliseconds: 500)); // Simulasi network

    try {
      // Tidak boleh hapus admin utama
      final user = _users.firstWhere((u) => u.id == userId);
      if (user.username == 'admin') {
        _errorMessage = 'Tidak dapat menghapus admin utama';
        _isLoading = false;
        notifyListeners();
        return false;
      }

      // ✅ DEBUG LOG
      print('🗑️ Deleting user: ${user.username}');

      // ✅ Auto-delete data guru jika role = guru
      if (user.role == AppConstants.roleGuru && _guruProvider != null) {
        await _guruProvider!.deleteGuru(userId);
        print('✅ Guru data deleted');
      }

      _users.removeWhere((u) => u.id == userId);
      print('✅ User deleted, total sekarang: ${_users.length}');
      
      filterByRole(_selectedRole); // Refresh filtered list
      
      _isLoading = false;
      notifyListeners();
      return true;
      
    } catch (e) {
      print('❌ Error deleteUser: $e');
      _errorMessage = 'Gagal menghapus user: $e';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // Get User by ID
  UserModel? getUserById(String id) {
    try {
      return _users.firstWhere((u) => u.id == id);
    } catch (e) {
      return null;
    }
  }

  // Get Total Users by Role
  int getTotalByRole(String role) {
    if (role == 'all') return _users.length;
    return _users.where((u) => u.role == role).length;
  }

  // ✅ Method untuk AuthProvider dengan DEBUG LOG
  List<UserModel> getAllUsers() {
    print('📦 getAllUsers() dipanggil, total: ${_users.length}');
    print('📋 Users: ${_users.map((u) => u.username).toList()}');
    return List.from(_users); // Return copy untuk keamanan
  }
}