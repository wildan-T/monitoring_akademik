import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/constants/app_constants.dart';
import '../../domain/entities/user_entity.dart';
import '../../data/models/user_model.dart';

class AuthProvider with ChangeNotifier {
  UserEntity? _currentUser;
  bool _isLoading = false;
  String? _errorMessage;

  UserEntity? get currentUser => _currentUser;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  bool get isLoggedIn => _currentUser != null;

  // ✅ TAMBAH: Callback untuk get users dari UserProvider
  List<UserModel> Function()? _getUsersCallback;

  // ✅ TAMBAH: Method untuk set callback
  void setGetUsersCallback(List<UserModel> Function() callback) {
    _getUsersCallback = callback;
  }

  // ✅ UPDATE: Login dengan dynamic user lookup
  Future<bool> login(String username, String password) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    // Simulasi delay network
    await Future.delayed(const Duration(seconds: 1));

    try {
      // ✅ Ambil users dari UserProvider jika callback tersedia
      List<UserModel> users = [];
      
      if (_getUsersCallback != null) {
        users = _getUsersCallback!();
      }
      
      // ✅ Fallback ke hardcoded users jika UserProvider belum ready
      if (users.isEmpty) {
        users = [
          UserModel(
            id: AppConstants.dummyAdmin['id'],
            username: AppConstants.dummyAdmin['username'],
            name: AppConstants.dummyAdmin['name'],
            role: AppConstants.dummyAdmin['role'],
            email: AppConstants.dummyAdmin['email'],
          ),
          UserModel(
            id: AppConstants.dummyGuru['id'],
            username: AppConstants.dummyGuru['username'],
            name: AppConstants.dummyGuru['name'],
            role: AppConstants.dummyGuru['role'],
            email: AppConstants.dummyGuru['email'],
          ),
          UserModel(
            id: AppConstants.dummyGuru2['id'],
            username: AppConstants.dummyGuru2['username'],
            name: AppConstants.dummyGuru2['name'],
            role: AppConstants.dummyGuru2['role'],
            email: AppConstants.dummyGuru2['email'],
          ),
          UserModel(
            id: AppConstants.dummyGuru3['id'],
            username: AppConstants.dummyGuru3['username'],
            name: AppConstants.dummyGuru3['name'],
            role: AppConstants.dummyGuru3['role'],
          ),
          UserModel(
            id: AppConstants.dummyWaliMurid['id'],
            username: AppConstants.dummyWaliMurid['username'],
            name: AppConstants.dummyWaliMurid['name'],
            role: AppConstants.dummyWaliMurid['role'],
            email: AppConstants.dummyWaliMurid['email'],
          ),
        ];
      }

      // ✅ Cari user berdasarkan username dan password
      UserModel? user;
      for (var u in users) {
        if (u.username == username && _validatePassword(u, password)) {
          user = u;
          break;
        }
      }

      if (user != null) {
        _currentUser = user;
        await _saveUserToPrefs(user);
        _isLoading = false;
        notifyListeners();
        return true;
      } else {
        _errorMessage = 'Username atau password salah';
        _isLoading = false;
        notifyListeners();
        return false;
      }
    } catch (e) {
      _errorMessage = 'Terjadi kesalahan: ${e.toString()}';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // ✅ TAMBAH: Helper method untuk validasi password
  bool _validatePassword(UserModel user, String password) {
    // Cek hardcoded password dari AppConstants dulu
    if (user.username == 'admin' && password == AppConstants.dummyAdmin['password']) {
      return true;
    }
    if (user.username == 'guru' && password == AppConstants.dummyGuru['password']) {
      return true;
    }
    if (user.username == 'guru2' && password == AppConstants.dummyGuru2['password']) {
      return true;
    }
    if (user.username == 'guru3' && password == AppConstants.dummyGuru3['password']) {
      return true;
    }
    if (user.username == 'wali' && password == AppConstants.dummyWaliMurid['password']) {
      return true;
    }
    
    // ✅ Untuk user baru, password default = username + "123"
    return password == '${user.username}123';
  }

  // Logout
  Future<void> logout() async {
    _currentUser = null;
    await _clearUserFromPrefs();
    notifyListeners();
  }

  // Check if user is logged in (saat app dibuka)
  Future<bool> checkLoginStatus() async {
    final prefs = await SharedPreferences.getInstance();
    final isLoggedIn = prefs.getBool(AppConstants.keyIsLoggedIn) ?? false;

    if (isLoggedIn) {
      final userId = prefs.getString(AppConstants.keyUserId) ?? '';
      final username = prefs.getString(AppConstants.keyUserName) ?? '';
      final userName = prefs.getString(AppConstants.keyUserName) ?? '';
      final userRole = prefs.getString(AppConstants.keyUserRole) ?? '';

      _currentUser = UserModel(
        id: userId,
        username: username,
        name: userName,
        role: userRole,
      );
      notifyListeners();
      return true;
    }
    
    return false;
  }

  // Save user to SharedPreferences
  Future<void> _saveUserToPrefs(UserEntity user) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(AppConstants.keyIsLoggedIn, true);
    await prefs.setString(AppConstants.keyUserId, user.id);
    await prefs.setString(AppConstants.keyUserName, user.name);
    await prefs.setString(AppConstants.keyUserRole, user.role);
  }

  // Clear user from SharedPreferences
  Future<void> _clearUserFromPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }
}