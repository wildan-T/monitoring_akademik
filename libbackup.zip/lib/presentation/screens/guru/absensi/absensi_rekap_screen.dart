import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../../../core/constants/color_constants.dart';
import '../../../providers/auth_provider.dart';
import '../../../providers/siswa_provider.dart';
import '../../../providers/absensi_provider.dart';
import '../../../providers/guru_provider.dart';

class AbsensiRekapScreen extends StatefulWidget {
  const AbsensiRekapScreen({super.key});

  @override
  State<AbsensiRekapScreen> createState() => _AbsensiRekapScreenState();
}

class _AbsensiRekapScreenState extends State<AbsensiRekapScreen> {
  String? _selectedKelas;
  int _selectedMonth = DateTime.now().month;
  int _selectedYear = DateTime.now().year;

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final guruProvider = Provider.of<GuruProvider>(context);

    // Get current guru
    final currentGuru = guruProvider.getGuruById(authProvider.currentUser?.id ?? '');

    // Get kelas list
    List<String> kelasList = [];
    if (currentGuru?.isWaliKelas ?? false) {
      kelasList.add(currentGuru!.waliKelas!);
      _selectedKelas ??= currentGuru.waliKelas;
    } else {
      kelasList = ['7A', '7B', '7C', '8A', '8B', '8C', '9A', '9B', '9C'];
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Rekap Absensi'),
        backgroundColor: AppColors.primary,
        foregroundColor: AppColors.white,
      ),
      body: Column(
        children: [
          // Header - Filter
          Container(
            padding: const EdgeInsets.all(16),
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Pilih Kelas
                if (kelasList.length > 1)
                  DropdownButtonFormField<String>(
                    value: _selectedKelas,
                    decoration: InputDecoration(
                      labelText: 'Pilih Kelas',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      filled: true,
                      fillColor: Colors.grey[100],
                    ),
                    items: kelasList.map((kelas) {
                      return DropdownMenuItem(
                        value: kelas,
                        child: Text('Kelas $kelas'),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedKelas = value;
                      });
                    },
                  ),
                const SizedBox(height: 16),

                // Pilih Bulan & Tahun
                Row(
                  children: [
                    Expanded(
                      child: DropdownButtonFormField<int>(
                        value: _selectedMonth,
                        decoration: InputDecoration(
                          labelText: 'Bulan',
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          filled: true,
                          fillColor: Colors.grey[100],
                        ),
                        items: List.generate(12, (index) {
                          final month = index + 1;
                          return DropdownMenuItem(
                            value: month,
                            child: Text(
                              DateFormat('MMMM', 'id_ID').format(DateTime(2024, month)),
                            ),
                          );
                        }),
                        onChanged: (value) {
                          setState(() {
                            _selectedMonth = value!;
                          });
                        },
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: DropdownButtonFormField<int>(
                        value: _selectedYear,
                        decoration: InputDecoration(
                          labelText: 'Tahun',
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          filled: true,
                          fillColor: Colors.grey[100],
                        ),
                        items: List.generate(5, (index) {
                          final year = DateTime.now().year - 2 + index;
                          return DropdownMenuItem(
                            value: year,
                            child: Text(year.toString()),
                          );
                        }),
                        onChanged: (value) {
                          setState(() {
                            _selectedYear = value!;
                          });
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // Rekap List
          if (_selectedKelas != null)
            Expanded(
              child: Consumer2<SiswaProvider, AbsensiProvider>(
                builder: (context, siswaProvider, absensiProvider, child) {
                  final siswaList = siswaProvider.getSiswaByKelas(_selectedKelas!);

                  if (siswaList.isEmpty) {
                    return const Center(
                      child: Text('Tidak ada siswa di kelas ini'),
                    );
                  }

                  return ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: siswaList.length,
                    itemBuilder: (context, index) {
                      final siswa = siswaList[index];
                      final rekap = absensiProvider.getRekapAbsensiSiswa(
                        siswaId: siswa.id,
                        month: _selectedMonth,
                        year: _selectedYear,
                      );
                      final persentase = absensiProvider.getPersentaseKehadiran(
                        siswaId: siswa.id,
                        month: _selectedMonth,
                        year: _selectedYear,
                      );

                      return Card(
                        margin: const EdgeInsets.only(bottom: 12),
                        elevation: 2,
                        child: ExpansionTile(
                          leading: CircleAvatar(
                            backgroundColor: AppColors.primary.withOpacity(0.1),
                            child: Text(
                              '${index + 1}',
                              style: const TextStyle(
                                color: AppColors.primary,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          title: Text(
                            siswa.nama,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          subtitle: Text(
                            'NISN: ${siswa.nisn}',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey[600],
                            ),
                          ),
                          trailing: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 6,
                            ),
                            decoration: BoxDecoration(
                              color: persentase >= 80
                                  ? AppColors.success.withOpacity(0.1)
                                  : AppColors.error.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              '${persentase.toStringAsFixed(1)}%',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: persentase >= 80
                                    ? AppColors.success
                                    : AppColors.error,
                              ),
                            ),
                          ),
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(16),
                              child: Column(
                                children: [
                                  // Summary Stats
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                                    children: [
                                      _buildStatColumn(
                                        'Hadir',
                                        rekap['hadir'] ?? 0,
                                        AppColors.success,
                                      ),
                                      _buildStatColumn(
                                        'Izin',
                                        rekap['izin'] ?? 0,
                                        Colors.orange,
                                      ),
                                      _buildStatColumn(
                                        'Sakit',
                                        rekap['sakit'] ?? 0,
                                        Colors.blue,
                                      ),
                                      _buildStatColumn(
                                        'Alpha',
                                        rekap['alpha'] ?? 0,
                                        AppColors.error,
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 12),
                                  const Divider(),
                                  const SizedBox(height: 8),
                                  
                                  // Detail Absensi
                                  _buildDetailAbsensi(
                                    absensiProvider,
                                    siswa.id,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  );
                },
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildStatColumn(String label, int value, Color color) {
    return Column(
      children: [
        Text(
          value.toString(),
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }

  Widget _buildDetailAbsensi(AbsensiProvider provider, String siswaId) {
    final absensiList = provider.getAbsensiBySiswaMonth(
      siswaId: siswaId,
      month: _selectedMonth,
      year: _selectedYear,
    );

    if (absensiList.isEmpty) {
      return Text(
        'Belum ada data absensi',
        style: TextStyle(
          fontSize: 12,
          color: Colors.grey[600],
          fontStyle: FontStyle.italic,
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Detail Absensi:',
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 8),
        ...absensiList.take(5).map((absensi) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 4),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  DateFormat('dd MMM yyyy', 'id_ID').format(absensi.tanggal),
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[700],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 2,
                  ),
                  decoration: BoxDecoration(
                    color: Color(int.parse(absensi.statusColor.replaceFirst('#', '0xff'))).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    absensi.statusLabel,
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: Color(int.parse(absensi.statusColor.replaceFirst('#', '0xff'))),
                    ),
                  ),
                ),
              ],
            ),
          );
        }).toList(),
        if (absensiList.length > 5)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Text(
              '+ ${absensiList.length - 5} lainnya',
              style: TextStyle(
                fontSize: 11,
                color: Colors.grey[600],
                fontStyle: FontStyle.italic,
              ),
            ),
          ),
      ],
    );
  }
}