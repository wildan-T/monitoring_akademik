import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../../../core/constants/color_constants.dart';
import '../../../../data/models/absensi_model.dart';
import '../../../providers/auth_provider.dart';
import '../../../providers/siswa_provider.dart';
import '../../../providers/absensi_provider.dart';
import '../../../providers/guru_provider.dart';

class AbsensiInputScreen extends StatefulWidget {
  const AbsensiInputScreen({super.key});

  @override
  State<AbsensiInputScreen> createState() => _AbsensiInputScreenState();
}

class _AbsensiInputScreenState extends State<AbsensiInputScreen> {
  DateTime _selectedDate = DateTime.now();
  String? _selectedKelas;
  final Map<String, AbsensiStatus> _absensiStatus = {};

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final guruProvider = Provider.of<GuruProvider>(context);

    // Get current guru
    final currentGuru = guruProvider.getGuruById(authProvider.currentUser?.id ?? '');

    // Get kelas list
    List<String> kelasList = [];
    if (currentGuru?.isWaliKelas ?? false) {
      kelasList.add(currentGuru!.waliKelas!);
      _selectedKelas ??= currentGuru.waliKelas;
    } else {
      kelasList = ['7A', '7B', '7C', '8A', '8B', '8C', '9A', '9B', '9C'];
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Input Absensi'),
        backgroundColor: AppColors.primary,
        foregroundColor: AppColors.white,
      ),
      body: Column(
        children: [
          // Header - Pilih Tanggal & Kelas
          Container(
            padding: const EdgeInsets.all(16),
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Pilih Tanggal
                Row(
                  children: [
                    const Icon(Icons.calendar_today, color: AppColors.primary),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Tanggal',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey,
                            ),
                          ),
                          Text(
                            DateFormat('EEEE, dd MMMM yyyy', 'id_ID')
                                .format(_selectedDate),
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                    TextButton.icon(
                      onPressed: () => _selectDate(context),
                      icon: const Icon(Icons.edit_calendar),
                      label: const Text('Ubah'),
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                // Pilih Kelas
                if (kelasList.length > 1)
                  DropdownButtonFormField<String>(
                    value: _selectedKelas,
                    decoration: InputDecoration(
                      labelText: 'Pilih Kelas',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      filled: true,
                      fillColor: Colors.grey[100],
                    ),
                    items: kelasList.map((kelas) {
                      return DropdownMenuItem(
                        value: kelas,
                        child: Text('Kelas $kelas'),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedKelas = value;
                        _absensiStatus.clear();
                      });
                    },
                  ),
              ],
            ),
          ),

          // List Siswa
          if (_selectedKelas != null)
            Expanded(
              child: Consumer<SiswaProvider>(
                builder: (context, siswaProvider, child) {
                  final siswaList = siswaProvider.getSiswaByKelas(_selectedKelas!);
                  
                  return Consumer<AbsensiProvider>(
                    builder: (context, absensiProvider, child) {
                      // Load existing absensi
                      if (_absensiStatus.isEmpty) {
                        final existingAbsensi = absensiProvider.getAbsensiByTanggalKelas(
                          tanggal: _selectedDate,
                          kelas: _selectedKelas!,
                        );
                        
                        for (var absensi in existingAbsensi) {
                          _absensiStatus[absensi.siswaId] = absensi.status;
                        }
                        
                        // Set default HADIR untuk yang belum ada
                        for (var siswa in siswaList) {
                          _absensiStatus[siswa.id] ??= AbsensiStatus.hadir;
                        }
                      }

                      if (siswaList.isEmpty) {
                        return const Center(
                          child: Text('Tidak ada siswa di kelas ini'),
                        );
                      }

                      return ListView.builder(
                        padding: const EdgeInsets.all(16),
                        itemCount: siswaList.length,
                        itemBuilder: (context, index) {
                          final siswa = siswaList[index];
                          final status = _absensiStatus[siswa.id] ?? AbsensiStatus.hadir;

                          return Card(
                            margin: const EdgeInsets.only(bottom: 12),
                            child: Padding(
                              padding: const EdgeInsets.all(16),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      CircleAvatar(
                                        backgroundColor: AppColors.primary.withOpacity(0.1),
                                        child: Text(
                                          '${index + 1}',
                                          style: const TextStyle(
                                            color: AppColors.primary,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                      const SizedBox(width: 12),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              siswa.nama,
                                              style: const TextStyle(
                                                fontSize: 16,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                            Text(
                                              'NISN: ${siswa.nisn}',
                                              style: TextStyle(
                                                fontSize: 12,
                                                color: Colors.grey[600],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 12),
                                  
                                  // Status Buttons
                                  Row(
                                    children: [
                                      Expanded(
                                        child: _buildStatusButton(
                                          'Hadir',
                                          AbsensiStatus.hadir,
                                          status,
                                          AppColors.success,
                                          siswa.id,
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Expanded(
                                        child: _buildStatusButton(
                                          'Izin',
                                          AbsensiStatus.izin,
                                          status,
                                          Colors.orange,
                                          siswa.id,
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Expanded(
                                        child: _buildStatusButton(
                                          'Sakit',
                                          AbsensiStatus.sakit,
                                          status,
                                          Colors.blue,
                                          siswa.id,
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Expanded(
                                        child: _buildStatusButton(
                                          'Alpha',
                                          AbsensiStatus.alpha,
                                          status,
                                          AppColors.error,
                                          siswa.id,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    },
                  );
                },
              ),
            ),
        ],
      ),
      bottomNavigationBar: _selectedKelas != null
          ? Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 10,
                  ),
                ],
              ),
              child: ElevatedButton(
                onPressed: () => _saveAbsensi(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: const Text(
                  'Simpan Absensi',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            )
          : null,
    );
  }

  Widget _buildStatusButton(
    String label,
    AbsensiStatus buttonStatus,
    AbsensiStatus currentStatus,
    Color color,
    String siswaId,
  ) {
    final isSelected = currentStatus == buttonStatus;

    return InkWell(
      onTap: () {
        setState(() {
          _absensiStatus[siswaId] = buttonStatus;
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? color : Colors.grey[100],
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: isSelected ? color : Colors.grey[300]!,
            width: 2,
          ),
        ),
        child: Text(
          label,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.bold,
            color: isSelected ? Colors.white : Colors.grey[700],
          ),
        ),
      ),
    );
  }

  Future<void> _selectDate(BuildContext context) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2024),
      lastDate: DateTime.now().add(const Duration(days: 30)),
    );

    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
        _absensiStatus.clear();
      });
    }
  }

  Future<void> _saveAbsensi(BuildContext context) async {
    final authProvider = context.read<AuthProvider>();
    final siswaProvider = context.read<SiswaProvider>();
    final absensiProvider = context.read<AbsensiProvider>();

    final siswaList = siswaProvider.getSiswaByKelas(_selectedKelas!);
    
    // Show loading
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const Center(
        child: CircularProgressIndicator(),
      ),
    );

    bool allSuccess = true;

    for (var siswa in siswaList) {
      final status = _absensiStatus[siswa.id] ?? AbsensiStatus.hadir;
      
      final success = await absensiProvider.saveAbsensi(
        siswaId: siswa.id,
        guruId: authProvider.currentUser?.id ?? '',
        kelas: _selectedKelas!,
        tanggal: _selectedDate,
        status: status,
      );

      if (!success) allSuccess = false;
    }

    if (context.mounted) {
      Navigator.pop(context); // Close loading

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            allSuccess
                ? 'Absensi berhasil disimpan'
                : 'Gagal menyimpan beberapa absensi',
          ),
          backgroundColor: allSuccess ? AppColors.success : AppColors.error,
        ),
      );

      if (allSuccess) {
        Navigator.pop(context); // Back to previous screen
      }
    }
  }
}