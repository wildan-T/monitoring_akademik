import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../../core/constants/color_constants.dart';
import '../../../providers/auth_provider.dart';
import '../../../providers/siswa_provider.dart';
import '../../../providers/guru_provider.dart';
import 'siswa_detail_screen.dart';

class SiswaListScreen extends StatefulWidget {
  const SiswaListScreen({super.key});

  @override
  State<SiswaListScreen> createState() => _SiswaListScreenState();
}

class _SiswaListScreenState extends State<SiswaListScreen> {
  String _searchQuery = '';
  String _selectedKelas = 'Semua';

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    //final siswaProvider = Provider.of<SiswaProvider>(context);
    final guruProvider = Provider.of<GuruProvider>(context);

    // Get current guru
    final currentGuru = guruProvider.getGuruById(authProvider.currentUser?.id ?? '');

    // Get kelas list
    List<String> kelasList = ['Semua'];
    if (currentGuru?.isWaliKelas ?? false) {
      kelasList.add(currentGuru!.waliKelas!);
    } else {
      // Guru mapel bisa lihat semua kelas yang dia ajar
      kelasList.addAll(['7A', '7B', '7C', '8A', '8B', '8C', '9A', '9B', '9C']);
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Data Siswa'),
        backgroundColor: AppColors.primary,
        foregroundColor: AppColors.white,
      ),
      body: Column(
        children: [
          // Search & Filter
          Container(
            padding: const EdgeInsets.all(16),
            color: Colors.white,
            child: Column(
              children: [
                // Search Bar
                TextField(
                  decoration: InputDecoration(
                    hintText: 'Cari siswa (nama/NISN)...',
                    prefixIcon: const Icon(Icons.search),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    filled: true,
                    fillColor: Colors.grey[100],
                  ),
                  onChanged: (value) {
                    setState(() {
                      _searchQuery = value.toLowerCase();
                    });
                  },
                ),
                const SizedBox(height: 12),
                
                // Filter Kelas
                Row(
                  children: [
                    const Text(
                      'Kelas:',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: kelasList.map((kelas) {
                            final isSelected = _selectedKelas == kelas;
                            return Padding(
                              padding: const EdgeInsets.only(right: 8),
                              child: ChoiceChip(
                                label: Text(kelas),
                                selected: isSelected,
                                onSelected: (selected) {
                                  setState(() {
                                    _selectedKelas = kelas;
                                  });
                                },
                                selectedColor: AppColors.primary,
                                labelStyle: TextStyle(
                                  color: isSelected ? Colors.white : Colors.black87,
                                  fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // Siswa List
          Expanded(
            child: Consumer<SiswaProvider>(
              builder: (context, provider, child) {
                // Filter siswa
                var filteredSiswa = provider.siswaList.where((siswa) {
                  // Filter by search query
                  final matchSearch = _searchQuery.isEmpty ||
                      siswa.nama.toLowerCase().contains(_searchQuery) ||
                      siswa.nisn.contains(_searchQuery);

                  // Filter by kelas
                  final matchKelas = _selectedKelas == 'Semua' ||
                      siswa.kelas == _selectedKelas;

                  return matchSearch && matchKelas;
                }).toList();

                if (filteredSiswa.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.people_outline,
                          size: 64,
                          color: Colors.grey[400],
                        ),
                        const SizedBox(height: 16),
                        Text(
                          'Tidak ada data siswa',
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey[600],
                          ),
                        ),
                      ],
                    ),
                  );
                }

                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: filteredSiswa.length,
                  itemBuilder: (context, index) {
                    final siswa = filteredSiswa[index];
                    return _buildSiswaCard(context, siswa);
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSiswaCard(BuildContext context, siswa) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => SiswaDetailScreen(siswa: siswa),
            ),
          );
        },
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              // Avatar
              CircleAvatar(
                radius: 30,
                backgroundColor: AppColors.primary.withOpacity(0.1),
                child: Text(
                  siswa.nama.substring(0, 1).toUpperCase(),
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: AppColors.primary,
                  ),
                ),
              ),
              const SizedBox(width: 16),

              // Info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      siswa.nama,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'NISN: ${siswa.nisn}',
                      style: TextStyle(
                        fontSize: 13,
                        color: Colors.grey[600],
                      ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: AppColors.primary.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            'Kelas ${siswa.kelas}',
                            style: const TextStyle(
                              fontSize: 11,
                              color: AppColors.primary,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Icon(
                          siswa.jenisKelamin == 'Laki-laki'
                              ? Icons.male
                              : Icons.female,
                          size: 16,
                          color: Colors.grey[600],
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              // Arrow
              Icon(
                Icons.chevron_right,
                color: Colors.grey[400],
              ),
            ],
          ),
        ),
      ),
    );
  }
}