//C:\Users\MSITHIN\monitoring_akademik\lib\presentation\screens\guru\nilai\nilai_input_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../../providers/nilai_provider.dart';
import '../../../../data/models/siswa_model.dart';


class NilaiInputScreen extends StatefulWidget {
  final SiswaModel siswa;
  final String kelas;
  final String mataPelajaran;
  final String guruId;

  const NilaiInputScreen({
    super.key,
    required this.siswa,
    required this.kelas,
    required this.mataPelajaran,
    required this.guruId,
  });

  @override
  State<NilaiInputScreen> createState() => _NilaiInputScreenState();
}

class _NilaiInputScreenState extends State<NilaiInputScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nilaiTugasController = TextEditingController();
  final _nilaiUHController = TextEditingController();
  final _nilaiUTSController = TextEditingController();
  final _nilaiUASController = TextEditingController();
  final _nilaiPraktikController = TextEditingController();
  String? _selectedNilaiSikap;

  @override
  void initState() {
    super.initState();
    _loadExistingNilai();
  }

  void _loadExistingNilai() {
    final nilaiProvider = Provider.of<NilaiProvider>(context, listen: false);
    final nilai = nilaiProvider.getNilai(
      siswaId: widget.siswa.id,
      kelas: widget.kelas,
      mataPelajaran: widget.mataPelajaran,
    );

    if (nilai != null) {
      _nilaiTugasController.text = nilai.nilaiTugas?.toString() ?? '';
      _nilaiUHController.text = nilai.nilaiUH?.toString() ?? '';
      _nilaiUTSController.text = nilai.nilaiUTS?.toString() ?? '';
      _nilaiUASController.text = nilai.nilaiUAS?.toString() ?? '';
      _nilaiPraktikController.text = nilai.nilaiPraktik?.toString() ?? '';
      _selectedNilaiSikap = nilai.nilaiSikap;
    }
  }

  @override
  void dispose() {
    _nilaiTugasController.dispose();
    _nilaiUHController.dispose();
    _nilaiUTSController.dispose();
    _nilaiUASController.dispose();
    _nilaiPraktikController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Input Nilai'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Header Siswa
            _buildHeaderSiswa(),

            // Form Input Nilai
            Form(
              key: _formKey,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildSectionTitle('Nilai Pengetahuan'),
                    const SizedBox(height: 12),
                    _buildNilaiField(
                      'Nilai Tugas (Bobot 20%)',
                      _nilaiTugasController,
                      'Masukkan nilai tugas (0-100)',
                    ),
                    const SizedBox(height: 12),
                    _buildNilaiField(
                      'Nilai Ulangan Harian (Bobot 20%)',
                      _nilaiUHController,
                      'Masukkan nilai UH (0-100)',
                    ),
                    const SizedBox(height: 12),
                    _buildNilaiField(
                      'Nilai UTS (Bobot 25%)',
                      _nilaiUTSController,
                      'Masukkan nilai UTS (0-100)',
                    ),
                    const SizedBox(height: 12),
                    _buildNilaiField(
                      'Nilai UAS (Bobot 25%)',
                      _nilaiUASController,
                      'Masukkan nilai UAS (0-100)',
                    ),
                    const SizedBox(height: 12),
                    _buildNilaiField(
                      'Nilai Praktik (Bobot 10%)',
                      _nilaiPraktikController,
                      'Masukkan nilai praktik (0-100)',
                    ),

                    const SizedBox(height: 24),
                    _buildSectionTitle('Nilai Sikap'),
                    const SizedBox(height: 12),
                    _buildNilaiSikapDropdown(),

                    const SizedBox(height: 32),
                    _buildPreviewNilaiAkhir(),

                    const SizedBox(height: 24),
                    _buildActionButtons(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeaderSiswa() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.blue.withOpacity(0.1),
      ),
      child: Column(
        children: [
          CircleAvatar(
            backgroundColor: widget.siswa.jenisKelamin == 'L'
                ? Colors.blue.withOpacity(0.2)
                : Colors.pink.withOpacity(0.2),
            radius: 40,
            child: Text(
              widget.siswa.nama.substring(0, 1).toUpperCase(),
              style: TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.bold,
                color: widget.siswa.jenisKelamin == 'L' ? Colors.blue : Colors.pink,
              ),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            widget.siswa.nama,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'NIS: ${widget.siswa.nis} • NISN: ${widget.siswa.nisn}',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.blue,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              'Kelas ${widget.kelas} - ${widget.mataPelajaran}',
              style: const TextStyle(
                fontSize: 12,
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: const TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.bold,
        color: Colors.blue,
      ),
    );
  }

  Widget _buildNilaiField(String label, TextEditingController controller, String hint) {
    return TextFormField(
      controller: controller,
      keyboardType: TextInputType.number,
      inputFormatters: [
        FilteringTextInputFormatter.digitsOnly,
        LengthLimitingTextInputFormatter(3),
      ],
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        filled: true,
        fillColor: Colors.grey[50],
      ),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return null; // Nilai boleh kosong
        }
        final nilai = int.tryParse(value);
        if (nilai == null || nilai < 0 || nilai > 100) {
          return 'Nilai harus antara 0-100';
        }
        return null;
      },
    );
  }

  Widget _buildNilaiSikapDropdown() {
    return DropdownButtonFormField<String>(
      value: _selectedNilaiSikap,
      decoration: InputDecoration(
        labelText: 'Nilai Sikap/Karakter',
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        filled: true,
        fillColor: Colors.grey[50],
      ),
      items: const [
        DropdownMenuItem(value: 'A', child: Text('A - Sangat Baik')),
        DropdownMenuItem(value: 'B', child: Text('B - Baik')),
        DropdownMenuItem(value: 'C', child: Text('C - Cukup')),
        DropdownMenuItem(value: 'D', child: Text('D - Perlu Bimbingan')),
      ],
      onChanged: (value) {
        setState(() {
          _selectedNilaiSikap = value;
        });
      },
    );
  }

  Widget _buildPreviewNilaiAkhir() {
    final nilaiTugas = double.tryParse(_nilaiTugasController.text);
    final nilaiUH = double.tryParse(_nilaiUHController.text);
    final nilaiUTS = double.tryParse(_nilaiUTSController.text);
    final nilaiUAS = double.tryParse(_nilaiUASController.text);
    final nilaiPraktik = double.tryParse(_nilaiPraktikController.text);

    double? nilaiAkhir;
    String? nilaiHuruf;
    String? predikat;

    if (nilaiTugas != null &&
        nilaiUH != null &&
        nilaiUTS != null &&
        nilaiUAS != null &&
        nilaiPraktik != null) {
      nilaiAkhir = (nilaiTugas * 0.2) +
          (nilaiUH * 0.2) +
          (nilaiUTS * 0.25) +
          (nilaiUAS * 0.25) +
          (nilaiPraktik * 0.1);

      if (nilaiAkhir >= 90) {
        nilaiHuruf = 'A';
        predikat = 'Sangat Baik';
      } else if (nilaiAkhir >= 80) {
        nilaiHuruf = 'B';
        predikat = 'Baik';
      } else if (nilaiAkhir >= 70) {
        nilaiHuruf = 'C';
        predikat = 'Cukup';
      } else if (nilaiAkhir >= 60) {
        nilaiHuruf = 'D';
        predikat = 'Kurang';
      } else {
        nilaiHuruf = 'E';
        predikat = 'Sangat Kurang';
      }
    }

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.green.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.green.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          const Text(
            'Preview Nilai Akhir',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Colors.green,
            ),
          ),
          const SizedBox(height: 12),
          if (nilaiAkhir != null) ...[
            Text(
              nilaiAkhir.toStringAsFixed(1),
              style: const TextStyle(
                fontSize: 48,
                fontWeight: FontWeight.bold,
                color: Colors.green,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              '$nilaiHuruf - $predikat',
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.green,
              ),
            ),
          ] else ...[
            const Text(
              '-',
              style: TextStyle(
                fontSize: 48,
                fontWeight: FontWeight.bold,
                color: Colors.grey,
              ),
            ),
            const SizedBox(height: 4),
            const Text(
              'Lengkapi semua nilai',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey,
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildActionButtons() {
    return Row(
      children: [
        Expanded(
          child: OutlinedButton(
            onPressed: () => Navigator.pop(context),
            style: OutlinedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 16),
              side: const BorderSide(color: Colors.blue),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: const Text(
              'BATAL',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.blue,
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: ElevatedButton(
            onPressed: _saveNilai,
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 16),
              backgroundColor: Colors.blue,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: const Text(
              'SIMPAN',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Future<void> _saveNilai() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    final nilaiProvider = Provider.of<NilaiProvider>(context, listen: false);

    final success = await nilaiProvider.saveNilai(
      siswaId: widget.siswa.id,
      guruId: widget.guruId,
      kelas: widget.kelas,
      mataPelajaran: widget.mataPelajaran,
      nilaiTugas: _nilaiTugasController.text.isEmpty
          ? null
          : double.parse(_nilaiTugasController.text),
      nilaiUH: _nilaiUHController.text.isEmpty
          ? null
          : double.parse(_nilaiUHController.text),
      nilaiUTS: _nilaiUTSController.text.isEmpty
          ? null
          : double.parse(_nilaiUTSController.text),
      nilaiUAS: _nilaiUASController.text.isEmpty
          ? null
          : double.parse(_nilaiUASController.text),
      nilaiPraktik: _nilaiPraktikController.text.isEmpty
          ? null
          : double.parse(_nilaiPraktikController.text),
      nilaiSikap: _selectedNilaiSikap,
    );

    if (mounted) {
      if (success) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Nilai berhasil disimpan!'),
            backgroundColor: Colors.green,
          ),
        );
        Navigator.pop(context);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(nilaiProvider.errorMessage ?? 'Gagal menyimpan nilai'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }
}