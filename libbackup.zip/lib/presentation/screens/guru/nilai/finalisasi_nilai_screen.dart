//C:\Users\MSITHIN\monitoring_akademik\lib\presentation\screens\guru\nilai\finalisasi_nilai_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../../../core/constants/color_constants.dart';
import '../../../providers/auth_provider.dart';
import '../../../providers/nilai_provider.dart';
import '../../../providers/guru_provider.dart';
import '../../../providers/siswa_provider.dart';

class FinalisasiNilaiScreen extends StatefulWidget {
  const FinalisasiNilaiScreen({super.key});

  @override
  State<FinalisasiNilaiScreen> createState() => _FinalisasiNilaiScreenState();
}

class _FinalisasiNilaiScreenState extends State<FinalisasiNilaiScreen> {
  String? _selectedKelasMapel;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Finalisasi Nilai'),
        backgroundColor: AppColors.primary,
        foregroundColor: AppColors.white,
      ),
      body: Consumer4<AuthProvider, NilaiProvider, GuruProvider, SiswaProvider>(
        builder: (context, authProvider, nilaiProvider, guruProvider, siswaProvider, child) {
          final currentGuru = guruProvider.getGuruById(authProvider.currentUser?.id ?? '');
          final kelasMapelList = nilaiProvider.getKelasMapelByGuruId(authProvider.currentUser?.id ?? '');
          final isWaliKelas = currentGuru?.isWaliKelas ?? false;

          return Column(
            children: [
              // Header Info
              _buildHeaderInfo(isWaliKelas, currentGuru?.waliKelas),

              // Filter Kelas-Mapel
              _buildKelasMapelDropdown(kelasMapelList),

              // List Nilai
              if (_selectedKelasMapel != null)
                Expanded(
                  child: _buildNilaiList(nilaiProvider, siswaProvider, kelasMapelList),
                ),
            ],
          );
        },
      ),
      bottomNavigationBar: _buildBottomBar(context),
    );
  }

  Widget _buildHeaderInfo(bool isWaliKelas, String? waliKelas) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      color: Colors.blue.shade50,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.info_outline, color: Colors.blue.shade700, size: 20),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  isWaliKelas
                      ? 'Anda adalah Wali Kelas $waliKelas. Anda dapat memfinalisasi semua nilai kelas Anda.'
                      : 'Hanya Wali Kelas yang dapat memfinalisasi nilai.',
                  style: TextStyle(fontSize: 13, color: Colors.blue.shade700),
                ),
              ),
            ],
          ),
          if (isWaliKelas) ...[
            const SizedBox(height: 8),
            Text(
              '⚠️ Nilai yang sudah difinalisasi tidak dapat diubah lagi!',
              style: TextStyle(
                fontSize: 12,
                color: Colors.red.shade700,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildKelasMapelDropdown(List kelasMapelList) {
    return Container(
      padding: const EdgeInsets.all(16),
      color: Colors.white,
      child: DropdownButtonFormField<String>(
        value: _selectedKelasMapel,
        decoration: InputDecoration(
          labelText: 'Pilih Kelas & Mata Pelajaran',
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
          filled: true,
          fillColor: Colors.grey[100],
        ),
        hint: const Text('-- Pilih Kelas & Mapel --'),
        items: kelasMapelList.map<DropdownMenuItem<String>>((kelasMapel) {
          return DropdownMenuItem<String>(
            value: kelasMapel.id,
            child: Text('${kelasMapel.kelas} - ${kelasMapel.mataPelajaran}'),
          );
        }).toList(),
        onChanged: (value) {
          setState(() {
            _selectedKelasMapel = value;
          });
        },
      ),
    );
  }

  Widget _buildNilaiList(nilaiProvider, siswaProvider, List kelasMapelList) {
    // cari objek kelasMapel yang dipilih
    final selectedKelasMapel = kelasMapelList.firstWhere(
      (km) => km.id == _selectedKelasMapel,
      orElse: () => null,
    );

    if (selectedKelasMapel == null) {
      return const Center(child: Text('Kelas & mapel tidak ditemukan.'));
    }

    // gunakan kelas & mataPelajaran sesuai signature provider
    final nilaiList = nilaiProvider.getNilaiByKelasMapel(
      kelas: selectedKelasMapel.kelas,
      mataPelajaran: selectedKelasMapel.mataPelajaran,
    );

    if (nilaiList.isEmpty) {
      return const Center(child: Text('Belum ada nilai yang diinput'));
    }

    final allFinalized = nilaiList.every((nilai) => nilai.isFinalized);

    return Column(
      children: [
        // Status Card
        Container(
          margin: const EdgeInsets.all(16),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: allFinalized ? Colors.green.shade50 : Colors.orange.shade50,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: allFinalized ? Colors.green.shade300 : Colors.orange.shade300,
            ),
          ),
          child: Row(
            children: [
              Icon(
                allFinalized ? Icons.check_circle : Icons.pending,
                color: allFinalized ? Colors.green.shade700 : Colors.orange.shade700,
                size: 32,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      allFinalized ? 'Nilai Sudah Difinalisasi' : 'Nilai Belum Difinalisasi',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: allFinalized ? Colors.green.shade700 : Colors.orange.shade700,
                      ),
                    ),
                    if (allFinalized && nilaiList.first.finalizedAt != null) ...[
                      const SizedBox(height: 4),
                      Text(
                        'Difinalisasi pada ${DateFormat('dd MMM yyyy HH:mm', 'id_ID').format(nilaiList.first.finalizedAt!)}',
                        style: TextStyle(fontSize: 12, color: Colors.grey[700]),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),

        // List Nilai
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: nilaiList.length,
            itemBuilder: (context, index) {
              final nilai = nilaiList[index];
              final siswa = siswaProvider.getSiswaById(nilai.siswaId);

              // aman: jika nilaiAkhir null tampil '-'
              final rataAkhir = nilai.nilaiAkhir;
              final rataAkhirText = rataAkhir != null ? rataAkhir.toStringAsFixed(1) : '-';

              return Card(
                margin: const EdgeInsets.only(bottom: 12),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Header
                      Row(
                        children: [
                          CircleAvatar(
                            backgroundColor: AppColors.primary.withOpacity(0.1),
                            child: Text(
                              '${index + 1}',
                              style: const TextStyle(
                                color: AppColors.primary,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  siswa?.nama ?? 'Unknown',
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  'NISN: ${siswa?.nisn ?? '-'}',
                                  style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                                ),
                              ],
                            ),
                          ),
                          if (nilai.isFinalized)
                            const Icon(Icons.verified, color: AppColors.success, size: 24),
                        ],
                      ),
                      const SizedBox(height: 12),
                      const Divider(height: 1),
                      const SizedBox(height: 12),

                      // Nilai Details (tampilkan null-safe)
                      Row(
                        children: [
                          Expanded(child: _buildNilaiItem('Tugas', nilai.nilaiTugas)),
                          Expanded(child: _buildNilaiItem('UH', nilai.nilaiUH)),
                          Expanded(child: _buildNilaiItem('UTS', nilai.nilaiUTS)),
                          Expanded(child: _buildNilaiItem('UAS', nilai.nilaiUAS)),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Expanded(child: _buildNilaiItem('Praktik', nilai.nilaiPraktik)),
                          // Sikap adalah huruf/string, tampilkan berbeda
                          Expanded(child: _buildSikapItem('Sikap', nilai.nilaiSikap)),
                          Expanded(
                            child: Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: AppColors.primary.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Column(
                                children: [
                                  const Text(
                                    'Rata-rata',
                                    style: TextStyle(
                                      fontSize: 11,
                                      color: AppColors.primary,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    rataAkhirText,
                                    style: const TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      color: AppColors.primary,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildNilaiItem(String label, double? nilai) {
    return Container(
      padding: const EdgeInsets.all(8),
      child: Column(
        children: [
          Text(label, style: TextStyle(fontSize: 11, color: Colors.grey[600])),
          const SizedBox(height: 4),
          Text(
            nilai != null ? nilai.toStringAsFixed(0) : '-',
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  Widget _buildSikapItem(String label, String? nilaiSikap) {
    return Container(
      padding: const EdgeInsets.all(8),
      child: Column(
        children: [
          Text(label, style: TextStyle(fontSize: 11, color: Colors.grey[600])),
          const SizedBox(height: 4),
          Text(
            nilaiSikap ?? '-',
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  Widget? _buildBottomBar(BuildContext context) {
    if (_selectedKelasMapel == null) return null;

    return Consumer2<AuthProvider, GuruProvider>(
      builder: (context, authProvider, guruProvider, child) {
        final currentGuru = guruProvider.getGuruById(authProvider.currentUser?.id ?? '');
        final isWaliKelas = currentGuru?.isWaliKelas ?? false;

        if (!isWaliKelas) return const SizedBox.shrink();

        return Consumer<NilaiProvider>(
          builder: (context, provider, child) {
            // cari kelasMapel object dari provider (gunakan same logic seperti di body)
            final kelasMapelList = provider.kelasMapelList;
            final selectedList = kelasMapelList.where((km) => km.id == _selectedKelasMapel);
            if (selectedList.isEmpty) return const SizedBox.shrink();
            final selected = selectedList.first;


            final nilaiList = provider.getNilaiByKelasMapel(
              kelas: selected.kelas,
              mataPelajaran: selected.mataPelajaran,
            );
            if (nilaiList.isEmpty) return const SizedBox.shrink();

            final allFinalized = nilaiList.every((nilai) => nilai.isFinalized);

            return Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10),
                ],
              ),
              child: ElevatedButton(
                onPressed: allFinalized ? null : () => _showFinalisasiDialog(context, selected.kelas, selected.mataPelajaran),
                style: ElevatedButton.styleFrom(
                  backgroundColor: allFinalized ? Colors.grey : AppColors.primary,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  disabledBackgroundColor: Colors.grey[300],
                ),
                child: Text(
                  allFinalized ? 'Nilai Sudah Difinalisasi' : 'Finalisasi Nilai',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _showFinalisasiDialog(BuildContext context, String kelas, String mataPelajaran) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Konfirmasi Finalisasi'),
        content: const Text(
          'Apakah Anda yakin ingin memfinalisasi nilai ini?\n\n'
          '⚠️ Nilai yang sudah difinalisasi tidak dapat diubah lagi!',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () => _finalisasiNilai(context, kelas, mataPelajaran),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              foregroundColor: Colors.white,
            ),
            child: const Text('Ya, Finalisasi'),
          ),
        ],
      ),
    );
  }

  Future<void> _finalisasiNilai(BuildContext context, String kelas, String mataPelajaran) async {
    final authProvider = context.read<AuthProvider>();
    final nilaiProvider = context.read<NilaiProvider>();

    Navigator.pop(context); // Close dialog

    // Show loading
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const Center(child: CircularProgressIndicator()),
    );

    final success = await nilaiProvider.finalisasiNilai(
      kelas: kelas,
      mataPelajaran: mataPelajaran,
      waliKelasId: authProvider.currentUser?.id ?? '',
    );

    if (context.mounted) {
      Navigator.pop(context); // Close loading

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(success ? 'Nilai berhasil difinalisasi' : 'Gagal memfinalisasi nilai'),
          backgroundColor: success ? AppColors.success : AppColors.error,
        ),
      );
    }
  }
}
