//C:\Users\MSITHIN\monitoring_akademik\lib\presentation\screens\guru\nilai\nilai_rekap_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../../providers/nilai_provider.dart';
import '../../../providers/siswa_provider.dart';
import '../../../providers/guru_provider.dart'; // ✅ TAMBAH IMPORT
import '../../../providers/auth_provider.dart'; // ✅ TAMBAH IMPORT
import '../../../../data/models/statistik_nilai_model.dart';
import '../../../../core/constants/color_constants.dart';

class NilaiRekapScreen extends StatelessWidget {
  final String kelas;
  final String mataPelajaran;

  const NilaiRekapScreen({
    super.key,
    required this.kelas,
    required this.mataPelajaran,
  });

  @override
  Widget build(BuildContext context) {
    final nilaiProvider = Provider.of<NilaiProvider>(context);
    final siswaProvider = Provider.of<SiswaProvider>(context);
    
    final statistik = nilaiProvider.getStatistikDetail(
      kelas: kelas,
      mataPelajaran: mataPelajaran,
    );

    final isFinalized = nilaiProvider.isNilaiFinalized(
      kelas: kelas,
      mataPelajaran: mataPelajaran,
    );

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Rekap Nilai'),
            Text(
              'Kelas $kelas - $mataPelajaran',
              style: const TextStyle(fontSize: 12),
            ),
          ],
        ),
        backgroundColor: AppColors.primary,
        foregroundColor: AppColors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.download),
            onPressed: () {
              _showExportDialog(context);
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Status Finalisasi
            if (isFinalized) _buildFinalisasiBadge(),
            if (isFinalized) const SizedBox(height: 16),

            // Card Statistik Umum
            _buildStatistikCard(statistik),
            const SizedBox(height: 16),

            // Grafik Distribusi Nilai
            _buildSectionTitle('Distribusi Nilai'),
            const SizedBox(height: 12),
            _buildDistribusiChart(statistik),
            const SizedBox(height: 24),

            // Grafik Persentase Kelulusan
            _buildSectionTitle('Persentase Kelulusan'),
            const SizedBox(height: 12),
            _buildKelulusanChart(statistik),
            const SizedBox(height: 24),

            // Tabel Detail Nilai Siswa
            _buildSectionTitle('Detail Nilai Siswa'),
            const SizedBox(height: 12),
            _buildDetailTable(nilaiProvider, siswaProvider),
          ],
        ),
      ),
      bottomNavigationBar: !isFinalized
          ? _buildFinalisasiButton(context, nilaiProvider, statistik)
          : null,
    );
  }

  Widget _buildFinalisasiBadge() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.success.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppColors.success),
      ),
      child: Row(
        children: [
          const Icon(Icons.lock, color: AppColors.success),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Nilai Sudah Difinalisasi',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: AppColors.success,
                  ),
                ),
                Text(
                  'Nilai tidak dapat diubah lagi',
                  style: TextStyle(
                    fontSize: 12,
                    color: AppColors.success.withOpacity(0.8),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatistikCard(StatistikNilaiModel statistik) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Statistik Umum',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: _buildStatItem(
                    'Total Siswa',
                    statistik.totalSiswa.toString(),
                    Icons.people,
                    AppColors.primary,
                  ),
                ),
                Expanded(
                  child: _buildStatItem(
                    'Sudah Dinilai',
                    statistik.sudahDinilai.toString(),
                    Icons.check_circle,
                    AppColors.success,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: _buildStatItem(
                    'Rata-rata',
                    statistik.rataRata.toStringAsFixed(1),
                    Icons.analytics,
                    AppColors.info,
                  ),
                ),
                Expanded(
                  child: _buildStatItem(
                    'Tertinggi',
                    statistik.nilaiTertinggi.toStringAsFixed(1),
                    Icons.arrow_upward,
                    AppColors.success,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            _buildStatItem(
              'Terendah',
              statistik.nilaiTerendah.toStringAsFixed(1),
              Icons.arrow_downward,
              AppColors.error,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem(String label, String value, IconData icon, Color color) {
    return Row(
      children: [
        Icon(icon, size: 20, color: color),
        const SizedBox(width: 8),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: const TextStyle(
                fontSize: 12,
                color: AppColors.textSecondary,
              ),
            ),
            Text(
              value,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: const TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.bold,
      ),
    );
  }

  Widget _buildDistribusiChart(StatistikNilaiModel statistik) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: SizedBox(
          height: 250,
          child: BarChart(
            BarChartData(
              alignment: BarChartAlignment.spaceAround,
              maxY: (statistik.sudahDinilai + 5).toDouble(),
              barTouchData: BarTouchData(enabled: true),
              titlesData: FlTitlesData(
                show: true,
                bottomTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    getTitlesWidget: (value, meta) {
                      const titles = ['A', 'B', 'C', 'D', 'E'];
                      return Text(
                        titles[value.toInt()],
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      );
                    },
                  ),
                ),
                leftTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    reservedSize: 40,
                  ),
                ),
                topTitles: const AxisTitles(
                  sideTitles: SideTitles(showTitles: false),
                ),
                rightTitles: const AxisTitles(
                  sideTitles: SideTitles(showTitles: false),
                ),
              ),
              borderData: FlBorderData(show: false),
              barGroups: [
                BarChartGroupData(
                  x: 0,
                  barRods: [
                    BarChartRodData(
                      toY: statistik.jumlahA.toDouble(),
                      color: AppColors.success,
                      width: 40,
                    ),
                  ],
                ),
                BarChartGroupData(
                  x: 1,
                  barRods: [
                    BarChartRodData(
                      toY: statistik.jumlahB.toDouble(),
                      color: AppColors.primary,
                      width: 40,
                    ),
                  ],
                ),
                BarChartGroupData(
                  x: 2,
                  barRods: [
                    BarChartRodData(
                      toY: statistik.jumlahC.toDouble(),
                      color: AppColors.warning,
                      width: 40,
                    ),
                  ],
                ),
                BarChartGroupData(
                  x: 3,
                  barRods: [
                    BarChartRodData(
                      toY: statistik.jumlahD.toDouble(),
                      color: Colors.orange,
                      width: 40,
                    ),
                  ],
                ),
                BarChartGroupData(
                  x: 4,
                  barRods: [
                    BarChartRodData(
                      toY: statistik.jumlahE.toDouble(),
                      color: AppColors.error,
                      width: 40,
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildKelulusanChart(StatistikNilaiModel statistik) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: SizedBox(
          height: 250,
          child: PieChart(
            PieChartData(
              sectionsSpace: 2,
              centerSpaceRadius: 60,
              sections: [
                PieChartSectionData(
                  value: statistik.persentaseKelulusan,
                  title: '${statistik.persentaseKelulusan.toStringAsFixed(1)}%',
                  color: AppColors.success,
                  radius: 80,
                  titleStyle: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: AppColors.white,
                  ),
                ),
                PieChartSectionData(
                  value: statistik.persentaseTidakLulus,
                  title: '${statistik.persentaseTidakLulus.toStringAsFixed(1)}%',
                  color: AppColors.error,
                  radius: 80,
                  titleStyle: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: AppColors.white,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDetailTable(NilaiProvider nilaiProvider, SiswaProvider siswaProvider) {
    final nilaiList = nilaiProvider.getNilaiByKelasMapel(
      kelas: kelas,
      mataPelajaran: mataPelajaran,
    );

    if (nilaiList.isEmpty) {
      return const Card(
        child: Padding(
          padding: EdgeInsets.all(32),
          child: Center(
            child: Text('Belum ada nilai'),
          ),
        ),
      );
    }

    return Card(
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          columns: const [
            DataColumn(label: Text('No')),
            DataColumn(label: Text('Nama Siswa')),
            DataColumn(label: Text('Tugas')),
            DataColumn(label: Text('UH')),
            DataColumn(label: Text('UTS')),
            DataColumn(label: Text('UAS')),
            DataColumn(label: Text('Praktik')),
            DataColumn(label: Text('Akhir')),
            DataColumn(label: Text('Huruf')),
          ],
          rows: nilaiList.asMap().entries.map((entry) {
            final index = entry.key;
            final nilai = entry.value;
            final siswa = siswaProvider.getSiswaById(nilai.siswaId);

            return DataRow(cells: [
              DataCell(Text('${index + 1}')),
              DataCell(Text(siswa?.nama ?? '-')),
              DataCell(Text(nilai.nilaiTugas?.toStringAsFixed(0) ?? '-')),
              DataCell(Text(nilai.nilaiUH?.toStringAsFixed(0) ?? '-')),
              DataCell(Text(nilai.nilaiUTS?.toStringAsFixed(0) ?? '-')),
              DataCell(Text(nilai.nilaiUAS?.toStringAsFixed(0) ?? '-')),
              DataCell(Text(nilai.nilaiPraktik?.toStringAsFixed(0) ?? '-')),
              DataCell(Text(nilai.nilaiAkhir?.toStringAsFixed(1) ?? '-')),
              DataCell(Text(nilai.nilaiHuruf ?? '-')),
            ]);
          }).toList(),
        ),
      ),
    );
  }

  // ✅ UPDATE METHOD INI
  Widget _buildFinalisasiButton(
    BuildContext context,
    NilaiProvider nilaiProvider,
    StatistikNilaiModel statistik,
  ) {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final guruProvider = Provider.of<GuruProvider>(context, listen: false);

    // ✅ LOGIKA BARU: Cek apakah user adalah wali kelas dari kelas ini
    final currentGuru = guruProvider.getGuruById(authProvider.currentUser?.id ?? '');
    final isWaliKelas = currentGuru?.waliKelas == kelas;

    // ✅ JIKA BUKAN WALI KELAS - Tampilkan info saja
    if (!isWaliKelas) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.info.withOpacity(0.1),
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(16),
            topRight: Radius.circular(16),
          ),
        ),
        child: Row(
          children: [
            Icon(
              Icons.info_outline,
              color: AppColors.info,
              size: 24,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                'Hanya Wali Kelas yang dapat melakukan finalisasi nilai',
                style: TextStyle(
                  color: AppColors.info,
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
      );
    }

    // ✅ JIKA MASIH ADA YANG BELUM DINILAI
    if (statistik.belumDinilai > 0) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.warning.withOpacity(0.1),
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(16),
            topRight: Radius.circular(16),
          ),
        ),
        child: Row(
          children: [
            Icon(
              Icons.warning_amber_rounded,
              color: AppColors.warning,
              size: 24,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                'Masih ada ${statistik.belumDinilai} siswa yang belum dinilai lengkap',
                style: TextStyle(
                  color: AppColors.warning,
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
      );
    }

    // ✅ SEMUA KONDISI TERPENUHI - Tampilkan tombol finalisasi
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: ElevatedButton.icon(
        onPressed: () => _showFinalisasiDialog(context, nilaiProvider, currentGuru!.id),
        icon: const Icon(Icons.lock, color: Colors.white),
        label: const Text(
          'FINALISASI NILAI',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.success,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }

  // ✅ UPDATE METHOD INI
  void _showFinalisasiDialog(
    BuildContext context,
    NilaiProvider nilaiProvider,
    String waliKelasId,
  ) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: AppColors.warning),
            const SizedBox(width: 8),
            const Text('Konfirmasi Finalisasi'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Apakah Anda yakin ingin finalisasi nilai?',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.error.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.info_outline, 
                        color: AppColors.error, 
                        size: 20,
                      ),
                      const SizedBox(width: 8),
                      const Text(
                        'PERHATIAN:',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: AppColors.error,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    '• Setelah difinalisasi, nilai tidak dapat diubah lagi',
                    style: TextStyle(fontSize: 13),
                  ),
                  const Text(
                    '• Nilai akan terkunci secara permanen',
                    style: TextStyle(fontSize: 13),
                  ),
                  const Text(
                    '• Raport siswa akan dapat dilihat wali murid',
                    style: TextStyle(fontSize: 13),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context);

              // ✅ Proses finalisasi
              final success = await nilaiProvider.finalisasiNilai(
                kelas: kelas,
                mataPelajaran: mataPelajaran,
                waliKelasId: waliKelasId,
              );

              if (success && context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Row(
                      children: [
                        Icon(Icons.check_circle, color: Colors.white),
                        const SizedBox(width: 8),
                        const Text('Nilai berhasil difinalisasi!'),
                      ],
                    ),
                    backgroundColor: AppColors.success,
                  ),
                );
              } else if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(nilaiProvider.errorMessage ?? 'Gagal finalisasi nilai'),
                    backgroundColor: AppColors.error,
                  ),
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.success,
            ),
            child: const Text(
              'Ya, Finalisasi',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  void _showExportDialog(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Export Rekap Nilai',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            ListTile(
              leading: const Icon(Icons.picture_as_pdf, color: AppColors.error),
              title: const Text('Export ke PDF'),
              onTap: () {
                Navigator.pop(context);
                // TODO: Implement export PDF
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Export PDF akan segera hadir')),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.table_chart, color: AppColors.success),
              title: const Text('Export ke Excel'),
              onTap: () {
                Navigator.pop(context);
                // TODO: Implement export Excel
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Export Excel akan segera hadir')),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}