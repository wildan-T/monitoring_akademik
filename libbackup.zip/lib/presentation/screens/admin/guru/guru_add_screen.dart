import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
//import '../../../../core/constants/color_constants.dart';
import '../../../../data/models/guru_model.dart';
import '../../../../presentation/providers/guru_provider.dart';

class GuruAddScreen extends StatefulWidget {
  const GuruAddScreen({super.key});

  @override
  State<GuruAddScreen> createState() => _GuruAddScreenState();
}

class _GuruAddScreenState extends State<GuruAddScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nipController = TextEditingController();
  final _nuptkController = TextEditingController();
  final _namaController = TextEditingController();
  final _tempatLahirController = TextEditingController();
  final _alamatController = TextEditingController();
  final _noTelpController = TextEditingController();
  final _emailController = TextEditingController();

  String _jenisKelamin = 'L';
  DateTime? _tanggalLahir;
  String _agama = 'Islam';
  String _pendidikanTerakhir = 'S1';
  List<String> _selectedMataPelajaran = [];
  String? _waliKelas;
  String _status = 'Aktif';
  bool _isLoading = false;

  final List<String> _daftarAgama = [
    'Islam',
    'Kristen',
    'Katolik',
    'Hindu',
    'Buddha',
    'Konghucu',
  ];

  final List<String> _daftarPendidikan = [
    'D3',
    'S1',
    'S2',
    'S3',
  ];

  final List<String> _daftarMataPelajaran = [
    'Matematika',
    'Bahasa Indonesia',
    'Bahasa Inggris',
    'IPA',
    'IPS',
    'PKN',
    'Seni Budaya',
    'PJOK',
    'Prakarya',
    'Agama Islam',
    'Informatika',
  ];

  final List<String> _daftarKelas = [
    '7A', '7B', '7C', '7D', '7E', '7F', '7G', '7H', '7I', '7J',
    '8A', '8B', '8C', '8D', '8E', '8F', '8G', '8H', '8I', '8J',
    '9A', '9B', '9C', '9D', '9E', '9F', '9G', '9H', '9I', '9J',
  ];

  @override
  void dispose() {
    _nipController.dispose();
    _nuptkController.dispose();
    _namaController.dispose();
    _tempatLahirController.dispose();
    _alamatController.dispose();
    _noTelpController.dispose();
    _emailController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tambah Data Guru'),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Section 1: Data Pribadi
            _buildSectionTitle('Data Pribadi'),
            _buildTextField(
              controller: _nipController,
              label: 'NIP',
              hint: 'Masukkan NIP',
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'NIP wajib diisi';
                }
                return null;
              },
            ),
            _buildTextField(
              controller: _nuptkController,
              label: 'NUPTK',
              hint: 'Masukkan NUPTK',
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'NUPTK wajib diisi';
                }
                return null;
              },
            ),
            _buildTextField(
              controller: _namaController,
              label: 'Nama Lengkap',
              hint: 'Masukkan nama lengkap',
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Nama wajib diisi';
                }
                return null;
              },
            ),
            _buildDropdown(
              label: 'Jenis Kelamin',
              value: _jenisKelamin,
              items: const ['L', 'P'],
              itemLabels: const ['Laki-laki', 'Perempuan'],
              onChanged: (value) {
                setState(() {
                  _jenisKelamin = value!;
                });
              },
            ),
            _buildTextField(
              controller: _tempatLahirController,
              label: 'Tempat Lahir',
              hint: 'Masukkan tempat lahir',
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Tempat lahir wajib diisi';
                }
                return null;
              },
            ),
            _buildDatePicker(
              label: 'Tanggal Lahir',
              value: _tanggalLahir,
              onChanged: (date) {
                setState(() {
                  _tanggalLahir = date;
                });
              },
            ),
            _buildDropdown(
              label: 'Agama',
              value: _agama,
              items: _daftarAgama,
              onChanged: (value) {
                setState(() {
                  _agama = value!;
                });
              },
            ),
            _buildTextField(
              controller: _alamatController,
              label: 'Alamat',
              hint: 'Masukkan alamat lengkap',
              maxLines: 3,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Alamat wajib diisi';
                }
                return null;
              },
            ),

            const SizedBox(height: 24),

            // Section 2: Kontak
            _buildSectionTitle('Informasi Kontak'),
            _buildTextField(
              controller: _noTelpController,
              label: 'No. Telepon',
              hint: 'Masukkan nomor telepon',
              keyboardType: TextInputType.phone,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'No. telepon wajib diisi';
                }
                return null;
              },
            ),
            _buildTextField(
              controller: _emailController,
              label: 'Email',
              hint: 'Masukkan alamat email',
              keyboardType: TextInputType.emailAddress,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Email wajib diisi';
                }
                if (!value.contains('@')) {
                  return 'Email tidak valid';
                }
                return null;
              },
            ),

            const SizedBox(height: 24),

            // Section 3: Data Akademik
            _buildSectionTitle('Data Akademik'),
            _buildDropdown(
              label: 'Pendidikan Terakhir',
              value: _pendidikanTerakhir,
              items: _daftarPendidikan,
              onChanged: (value) {
                setState(() {
                  _pendidikanTerakhir = value!;
                });
              },
            ),
            _buildMultiSelectMataPelajaran(),
            _buildWaliKelasDropdown(),
            _buildDropdown(
              label: 'Status',
              value: _status,
              items: const ['Aktif', 'Cuti', 'Pensiun'],
              onChanged: (value) {
                setState(() {
                  _status = value!;
                });
              },
            ),

            const SizedBox(height: 32),

            // Button Submit
            SizedBox(
              height: 50,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _submitForm,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: _isLoading
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                    : const Text(
                        'SIMPAN DATA GURU',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16, top: 8),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: Colors.blue,
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    String? Function(String?)? validator,
    TextInputType? keyboardType,
    int maxLines = 1,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextFormField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        validator: validator,
        keyboardType: keyboardType,
        maxLines: maxLines,
      ),
    );
  }

  Widget _buildDropdown({
    required String label,
    required String value,
    required List<String> items,
    List<String>? itemLabels,
    required void Function(String?) onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: DropdownButtonFormField<String>(
        value: value,
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        items: items.map((item) {
          final displayLabel = itemLabels != null
              ? itemLabels[items.indexOf(item)]
              : item;
          return DropdownMenuItem(
            value: item,
            child: Text(displayLabel),
          );
        }).toList(),
        onChanged: onChanged,
      ),
    );
  }

  Widget _buildDatePicker({
    required String label,
    required DateTime? value,
    required void Function(DateTime?) onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextFormField(
        readOnly: true,
        decoration: InputDecoration(
          labelText: label,
          hintText: 'Pilih tanggal lahir',
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          suffixIcon: const Icon(Icons.calendar_today),
        ),
        controller: TextEditingController(
          text: value != null
              ? '${value.day.toString().padLeft(2, '0')}-'
                  '${value.month.toString().padLeft(2, '0')}-'
                  '${value.year}'
              : '',
        ),
        onTap: () async {
          final picked = await showDatePicker(
            context: context,
            initialDate: value ?? DateTime(1990),
            firstDate: DateTime(1950),
            lastDate: DateTime.now(),
          );
          if (picked != null) {
            onChanged(picked);
          }
        },
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Tanggal lahir wajib diisi';
          }
          return null;
        },
      ),
    );
  }

  Widget _buildMultiSelectMataPelajaran() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Mata Pelajaran yang Diajar *',
            style: TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _daftarMataPelajaran.map((mapel) {
              final isSelected = _selectedMataPelajaran.contains(mapel);
              return FilterChip(
                label: Text(mapel),
                selected: isSelected,
                onSelected: (selected) {
                  setState(() {
                    if (selected) {
                      _selectedMataPelajaran.add(mapel);
                    } else {
                      _selectedMataPelajaran.remove(mapel);
                    }
                  });
                },
              );
            }).toList(),
          ),
          if (_selectedMataPelajaran.isEmpty)
            const Padding(
              padding: EdgeInsets.only(top: 8),
              child: Text(
                'Pilih minimal 1 mata pelajaran',
                style: TextStyle(color: Colors.red, fontSize: 12),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildWaliKelasDropdown() {
    final usedWaliKelas = context.read<GuruProvider>().usedWaliKelas;
    final availableKelas = _daftarKelas
        .where((kelas) => !usedWaliKelas.contains(kelas))
        .toList();

    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: DropdownButtonFormField<String>(
        value: _waliKelas,
        decoration: InputDecoration(
          labelText: 'Wali Kelas (Opsional)',
          hintText: 'Pilih kelas jika menjadi wali kelas',
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        items: [
          const DropdownMenuItem(
            value: null,
            child: Text('Tidak jadi wali kelas'),
          ),
          ...availableKelas.map((kelas) {
            return DropdownMenuItem(
              value: kelas,
              child: Text(kelas),
            );
          }),
        ],
        onChanged: (value) {
          setState(() {
            _waliKelas = value;
          });
        },
      ),
    );
  }

  Future<void> _submitForm() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    if (_tanggalLahir == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Tanggal lahir wajib diisi'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    if (_selectedMataPelajaran.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Pilih minimal 1 mata pelajaran'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    final newGuru = GuruModel(
      id: '', // Will be generated by provider
      nip: _nipController.text,
      nuptk: _nuptkController.text.isEmpty ? null : _nuptkController.text,
      nama: _namaController.text,
      jenisKelamin: _jenisKelamin,
      tempatLahir: _tempatLahirController.text,
      tanggalLahir: _tanggalLahir!,
      agama: _agama,
      alamat: _alamatController.text,
      noTelp: _noTelpController.text,
      email: _emailController.text,
      pendidikanTerakhir: _pendidikanTerakhir,
      mataPelajaran: _selectedMataPelajaran,
      waliKelas: _waliKelas,
      status: _status,
      createdAt: DateTime.now(),
      
    );

    final success = await context.read<GuruProvider>().addGuru(newGuru);

    setState(() {
      _isLoading = false;
    });

    if (mounted) {
      if (success) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Data guru berhasil ditambahkan'),
            backgroundColor: Colors.green,
          ),
        );
        Navigator.pop(context);
      } else {
        final errorMessage = context.read<GuruProvider>().errorMessage;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(errorMessage ?? 'Gagal menambahkan data guru'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }
}