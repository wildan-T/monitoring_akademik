import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
//import '../../../../core/constants/color_constants.dart';
import '../../../../data/models/guru_model.dart';
import '../../../../presentation/providers/guru_provider.dart';

class GuruEditScreen extends StatefulWidget {
  final GuruModel guru;

  const GuruEditScreen({super.key, required this.guru});

  @override
  State<GuruEditScreen> createState() => _GuruEditScreenState();
}

class _GuruEditScreenState extends State<GuruEditScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nipController;
  late TextEditingController _nuptkController;
  late TextEditingController _namaController;
  late TextEditingController _tempatLahirController;
  late TextEditingController _alamatController;
  late TextEditingController _noTelpController;
  late TextEditingController _emailController;

  late String _jenisKelamin;
  late DateTime? _tanggalLahir;
  late String _agama;
  late String _pendidikanTerakhir;
  late List<String> _selectedMataPelajaran;
  late String? _waliKelas;
  late String _status;
  bool _isLoading = false;

  final List<String> _daftarAgama = [
    'Islam',
    'Kristen',
    'Katolik',
    'Hindu',
    'Buddha',
    'Konghucu',
  ];

  final List<String> _daftarPendidikan = [
    'D3',
    'S1',
    'S2',
    'S3',
  ];

  final List<String> _daftarMataPelajaran = [
    'Matematika',
    'Bahasa Indonesia',
    'Bahasa Inggris',
    'IPA',
    'IPS',
    'PKN',
    'Seni Budaya',
    'PJOK',
    'Prakarya',
    'Agama Islam',
    'Informatika',
  ];

  final List<String> _daftarKelas = [
    '7A', '7B', '7C', '7D', '7E', '7F', '7G', '7H', '7I', '7J',
    '8A', '8B', '8C', '8D', '8E', '8F', '8G', '8H', '8I', '8J',
    '9A', '9B', '9C', '9D', '9E', '9F', '9G', '9H', '9I', '9J',
  ];

  final List<String> _daftarStatus = [
    'Aktif',
    'Cuti',
    'Pensiun',
  ];

  @override
  void initState() {
    super.initState();
    // Initialize controllers with existing data
    _nipController = TextEditingController(text: widget.guru.nip);
    _nuptkController = TextEditingController(text: widget.guru.nuptk);
    _namaController = TextEditingController(text: widget.guru.nama);
    _tempatLahirController = TextEditingController(text: widget.guru.tempatLahir);
    _alamatController = TextEditingController(text: widget.guru.alamat);
    _noTelpController = TextEditingController(text: widget.guru.noTelp);
    _emailController = TextEditingController(text: widget.guru.email);

    _jenisKelamin = widget.guru.jenisKelamin;
    _tanggalLahir = widget.guru.tanggalLahir;
    _agama = widget.guru.agama;
    _pendidikanTerakhir = widget.guru.pendidikanTerakhir;
    _selectedMataPelajaran = List.from(widget.guru.mataPelajaran);
    _waliKelas = widget.guru.waliKelas;
    _status = widget.guru.status;
  }

  @override
  void dispose() {
    _nipController.dispose();
    _nuptkController.dispose();
    _namaController.dispose();
    _tempatLahirController.dispose();
    _alamatController.dispose();
    _noTelpController.dispose();
    _emailController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Data Guru'),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Info Banner
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.blue[50],
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.blue[200]!),
              ),
              child: Row(
                children: [
                  Icon(Icons.info_outline, color: Colors.blue[700]),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Anda sedang mengedit data guru:\n${widget.guru.nama}',
                      style: TextStyle(
                        color: Colors.blue[900],
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Section 1: Data Pribadi
            _buildSectionTitle('Data Pribadi'),
            _buildTextField(
              controller: _nipController,
              label: 'NIP',
              hint: 'Masukkan NIP',
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'NIP wajib diisi';
                }
                return null;
              },
            ),
            _buildTextField(
              controller: _nuptkController,
              label: 'NUPTK',
              hint: 'Masukkan NUPTK',
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'NUPTK wajib diisi';
                }
                return null;
              },
            ),
            _buildTextField(
              controller: _namaController,
              label: 'Nama Lengkap',
              hint: 'Masukkan nama lengkap',
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Nama wajib diisi';
                }
                return null;
              },
            ),
            _buildDropdown(
              label: 'Jenis Kelamin',
              value: _jenisKelamin,
              items: const ['L', 'P'],
              itemLabels: const ['Laki-laki', 'Perempuan'],
              onChanged: (value) {
                setState(() {
                  _jenisKelamin = value!;
                });
              },
            ),
            _buildTextField(
              controller: _tempatLahirController,
              label: 'Tempat Lahir',
              hint: 'Masukkan tempat lahir',
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Tempat lahir wajib diisi';
                }
                return null;
              },
            ),
            _buildDatePicker(
              label: 'Tanggal Lahir',
              value: _tanggalLahir,
              onChanged: (date) {
                setState(() {
                  _tanggalLahir = date;
                });
              },
            ),
            _buildDropdown(
              label: 'Agama',
              value: _agama,
              items: _daftarAgama,
              onChanged: (value) {
                setState(() {
                  _agama = value!;
                });
              },
            ),
            _buildTextField(
              controller: _alamatController,
              label: 'Alamat',
              hint: 'Masukkan alamat lengkap',
              maxLines: 3,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Alamat wajib diisi';
                }
                return null;
              },
            ),

            const SizedBox(height: 24),

            // Section 2: Kontak
            _buildSectionTitle('Informasi Kontak'),
            _buildTextField(
              controller: _noTelpController,
              label: 'No. Telepon',
              hint: 'Masukkan nomor telepon',
              keyboardType: TextInputType.phone,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'No. telepon wajib diisi';
                }
                return null;
              },
            ),
            _buildTextField(
              controller: _emailController,
              label: 'Email',
              hint: 'Masukkan alamat email',
              keyboardType: TextInputType.emailAddress,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Email wajib diisi';
                }
                if (!value.contains('@')) {
                  return 'Email tidak valid';
                }
                return null;
              },
            ),

            const SizedBox(height: 24),

            // Section 3: Data Akademik
            _buildSectionTitle('Data Akademik'),
            _buildDropdown(
              label: 'Pendidikan Terakhir',
              value: _pendidikanTerakhir,
              items: _daftarPendidikan,
              onChanged: (value) {
                setState(() {
                  _pendidikanTerakhir = value!;
                });
              },
            ),
            _buildMultiSelectMataPelajaran(),
            _buildWaliKelasDropdown(),
            _buildDropdown(
              label: 'Status',
              value: _status,
              items: _daftarStatus,
              onChanged: (value) {
                setState(() {
                  _status = value!;
                });
              },
            ),

            const SizedBox(height: 32),

            // Button Submit
            SizedBox(
              height: 50,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _submitForm,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: _isLoading
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                    : const Text(
                        'UPDATE DATA GURU',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
              ),
            ),

            const SizedBox(height: 16),

            // Button Batal
            SizedBox(
              height: 50,
              child: OutlinedButton(
                onPressed: _isLoading ? null : () => Navigator.pop(context),
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: Colors.blue,),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: const Text(
                  'BATAL',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.blue,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16, top: 8),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: Colors.blue,
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    String? Function(String?)? validator,
    TextInputType? keyboardType,
    int maxLines = 1,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextFormField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        validator: validator,
        keyboardType: keyboardType,
        maxLines: maxLines,
      ),
    );
  }

  Widget _buildDropdown({
    required String label,
    required String value,
    required List<String> items,
    List<String>? itemLabels,
    required void Function(String?) onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: DropdownButtonFormField<String>(
        value: value,
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        items: items.map((item) {
          final displayLabel = itemLabels != null
              ? itemLabels[items.indexOf(item)]
              : item;
          return DropdownMenuItem(
            value: item,
            child: Text(displayLabel),
          );
        }).toList(),
        onChanged: onChanged,
      ),
    );
  }

  Widget _buildDatePicker({
    required String label,
    required DateTime? value,
    required void Function(DateTime?) onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextFormField(
        readOnly: true,
        decoration: InputDecoration(
          labelText: label,
          hintText: 'Pilih tanggal lahir',
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          suffixIcon: const Icon(Icons.calendar_today),
        ),
        controller: TextEditingController(
          text: value != null
              ? '${value.day.toString().padLeft(2, '0')}-'
                  '${value.month.toString().padLeft(2, '0')}-'
                  '${value.year}'
              : '',
        ),
        onTap: () async {
          final picked = await showDatePicker(
            context: context,
            initialDate: value ?? DateTime(1990),
            firstDate: DateTime(1950),
            lastDate: DateTime.now(),
          );
          if (picked != null) {
            onChanged(picked);
          }
        },
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Tanggal lahir wajib diisi';
          }
          return null;
        },
      ),
    );
  }

  Widget _buildMultiSelectMataPelajaran() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Mata Pelajaran yang Diajar *',
            style: TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _daftarMataPelajaran.map((mapel) {
              final isSelected = _selectedMataPelajaran.contains(mapel);
              return FilterChip(
                label: Text(mapel),
                selected: isSelected,
                onSelected: (selected) {
                  setState(() {
                    if (selected) {
                      _selectedMataPelajaran.add(mapel);
                    } else {
                      _selectedMataPelajaran.remove(mapel);
                    }
                  });
                },
              );
            }).toList(),
          ),
          if (_selectedMataPelajaran.isEmpty)
            const Padding(
              padding: EdgeInsets.only(top: 8),
              child: Text(
                'Pilih minimal 1 mata pelajaran',
                style: TextStyle(color: Colors.red, fontSize: 12),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildWaliKelasDropdown() {
    final usedWaliKelas = context.read<GuruProvider>().usedWaliKelas;
    
    // Available kelas adalah kelas yang belum dipakai ATAU kelas yang saat ini dipakai oleh guru ini
    final availableKelas = _daftarKelas.where((kelas) {
      return !usedWaliKelas.contains(kelas) || kelas == widget.guru.waliKelas;
    }).toList();

    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: DropdownButtonFormField<String>(
        value: _waliKelas,
        decoration: InputDecoration(
          labelText: 'Wali Kelas (Opsional)',
          hintText: 'Pilih kelas jika menjadi wali kelas',
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        items: [
          const DropdownMenuItem(
            value: null,
            child: Text('Tidak jadi wali kelas'),
          ),
          ...availableKelas.map((kelas) {
            return DropdownMenuItem(
              value: kelas,
              child: Text(kelas),
            );
          }),
        ],
        onChanged: (value) {
          setState(() {
            _waliKelas = value;
          });
        },
      ),
    );
  }

  Future<void> _submitForm() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    if (_tanggalLahir == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Tanggal lahir wajib diisi'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    if (_selectedMataPelajaran.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Pilih minimal 1 mata pelajaran'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    final updatedGuru = GuruModel(
      id: widget.guru.id,
      nip: _nipController.text,
      nuptk: _nuptkController.text,
      nama: _namaController.text,
      jenisKelamin: _jenisKelamin,
      tempatLahir: _tempatLahirController.text,
      tanggalLahir: _tanggalLahir!,
      agama: _agama,
      alamat: _alamatController.text,
      noTelp: _noTelpController.text,
      email: _emailController.text,
      pendidikanTerakhir: _pendidikanTerakhir,
      mataPelajaran: _selectedMataPelajaran,
      waliKelas: _waliKelas,
      status: _status,
      createdAt: widget.guru.createdAt,
    );

   final success = await context.read<GuruProvider>().updateGuru(updatedGuru);
   

    setState(() {
      _isLoading = false;
    });

    if (mounted) {
      if (success) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Data guru berhasil diupdate'),
            backgroundColor: Colors.green,
          ),
        );
        Navigator.pop(context);
      } else {
        final errorMessage = context.read<GuruProvider>().errorMessage;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(errorMessage ?? 'Gagal mengupdate data guru'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }
}