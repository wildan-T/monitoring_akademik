import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
//import '../../../../core/constants/color_constants.dart';
import '../../../../data/models/guru_model.dart';
import '../../../../presentation/providers/guru_provider.dart';
import 'guru_add_screen.dart';
import 'guru_edit_screen.dart';

class GuruListScreen extends StatefulWidget {
  const GuruListScreen({super.key});

  @override
  State<GuruListScreen> createState() => _GuruListScreenState();
}

class _GuruListScreenState extends State<GuruListScreen> {
  final TextEditingController _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Kelola Data Guru'),
        actions: [
          IconButton(
            icon: const Icon(Icons.filter_list),
            onPressed: () => _showFilterDialog(context),
          ),
        ],
      ),
      body: Column(
        children: [
          // Search Bar
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Cari guru (Nama, NIP, NUPTK)...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                          context.read<GuruProvider>().setSearchQuery('');
                        },
                      )
                    : null,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: Colors.grey[100],
              ),
              onChanged: (value) {
                context.read<GuruProvider>().setSearchQuery(value);
              },
            ),
          ),

          // Filter Chips
          Consumer<GuruProvider>(
            builder: (context, provider, _) {
              if (provider.filterMataPelajaran != 'Semua' ||
                  provider.filterStatus != 'Semua') {
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Row(
                    children: [
                      if (provider.filterMataPelajaran != 'Semua')
                        Padding(
                          padding: const EdgeInsets.only(right: 8.0),
                          child: Chip(
                            label: Text(provider.filterMataPelajaran),
                            deleteIcon: const Icon(Icons.close, size: 18),
                            onDeleted: () {
                              provider.setFilterMataPelajaran('Semua');
                            },
                          ),
                        ),
                      if (provider.filterStatus != 'Semua')
                        Chip(
                          label: Text(provider.filterStatus),
                          deleteIcon: const Icon(Icons.close, size: 18),
                          onDeleted: () {
                            provider.setFilterStatus('Semua');
                          },
                        ),
                      const Spacer(),
                      TextButton(
                        onPressed: () => provider.clearFilters(),
                        child: const Text('Reset Filter'),
                      ),
                    ],
                  ),
                );
              }
              return const SizedBox.shrink();
            },
          ),

          // List Guru
          Expanded(
            child: Consumer<GuruProvider>(
              builder: (context, provider, _) {
                if (provider.isLoading) {
                  return const Center(child: CircularProgressIndicator());
                }

                if (provider.guruList.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.school_outlined,
                          size: 80,
                          color: Colors.grey[400],
                        ),
                        const SizedBox(height: 16),
                        Text(
                          'Belum ada data guru',
                          style: TextStyle(
                            fontSize: 18,
                            color: Colors.grey[600],
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Tambahkan guru dengan menekan tombol +',
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey[500],
                          ),
                        ),
                      ],
                    ),
                  );
                }

                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: provider.guruList.length,
                  itemBuilder: (context, index) {
                    final guru = provider.guruList[index];
                    return _buildGuruCard(context, guru);
                  },
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const GuruAddScreen()),
          );
        },
        icon: const Icon(Icons.add),
        label: const Text('Tambah Guru'),
      ),
    );
  }

  Widget _buildGuruCard(BuildContext context, GuruModel guru) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => _showDetailDialog(context, guru),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            children: [
              // Avatar dengan inisial
              CircleAvatar(
                radius: 30,
                backgroundColor: guru.jenisKelamin == 'L'
                    ? Colors.blue[100]
                    : Colors.pink[100],
                child: Text(
                  guru.nama.split(' ').map((e) => e[0]).take(2).join(),
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: guru.jenisKelamin == 'L'
                        ? Colors.blue[700]
                        : Colors.pink[700],
                  ),
                ),
              ),
              const SizedBox(width: 16),

              // Info Guru
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      guru.nama,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'NIP: ${guru.nip}',
                      style: TextStyle(
                        fontSize: 13,
                        color: Colors.grey[600],
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      guru.mataPelajaranString,
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey[700],
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        // Badge Wali Kelas
                        if (guru.isWaliKelas)
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.blue.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              'Wali Kelas ${guru.waliKelas}',
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                color: Colors.blue,
                              ),
                            ),
                          ),
                        const SizedBox(width: 8),

                        // Badge Status
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: _getStatusColor(guru.status).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            guru.status,
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              color: _getStatusColor(guru.status),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              // Menu Actions
              PopupMenuButton<String>(
                icon: const Icon(Icons.more_vert),
                onSelected: (value) {
                  if (value == 'edit') {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => GuruEditScreen(guru: guru),
                      ),
                    );
                  } else if (value == 'delete') {
                    _showDeleteConfirmation(context, guru);
                  }
                },
                itemBuilder: (context) => [
                  const PopupMenuItem(
                    value: 'detail',
                    child: Row(
                      children: [
                        Icon(Icons.info_outline, size: 20),
                        SizedBox(width: 8),
                        Text('Detail'),
                      ],
                    ),
                  ),
                  const PopupMenuItem(
                    value: 'edit',
                    child: Row(
                      children: [
                        Icon(Icons.edit_outlined, size: 20),
                        SizedBox(width: 8),
                        Text('Edit'),
                      ],
                    ),
                  ),
                  const PopupMenuItem(
                    value: 'delete',
                    child: Row(
                      children: [
                        Icon(Icons.delete_outline, size: 20, color: Colors.red),
                        SizedBox(width: 8),
                        Text('Hapus', style: TextStyle(color: Colors.red)),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'Aktif':
        return Colors.green;
      case 'Cuti':
        return Colors.orange;
      case 'Pensiun':
        return Colors.grey;
      default:
        return Colors.blue;
    }
  }

  void _showDetailDialog(BuildContext context, GuruModel guru) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Detail Guru'),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildDetailRow('NIP', guru.nip),
              _buildDetailRow('NUPTK', guru.nuptk ?? '-'),
              _buildDetailRow('Nama', guru.nama),
              _buildDetailRow('Jenis Kelamin', guru.jenisKelamin == 'L' ? 'Laki-laki' : 'Perempuan'),
              _buildDetailRow('Tempat, Tanggal Lahir', '${guru.tempatLahir}, ${guru.tanggalLahirFormatted}'),
              _buildDetailRow('Umur', '${guru.umur} tahun'),
              _buildDetailRow('Agama', guru.agama),
              _buildDetailRow('Alamat', guru.alamat),
              _buildDetailRow('No. Telepon', guru.noTelp),
              _buildDetailRow('Email', guru.email),
              _buildDetailRow('Pendidikan Terakhir', guru.pendidikanTerakhir),
              _buildDetailRow('Mata Pelajaran', guru.mataPelajaranString),
              _buildDetailRow('Wali Kelas', guru.isWaliKelas ? guru.waliKelas! : '-'),
              _buildDetailRow('Status', guru.status),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tutup'),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 130,
            child: Text(
              label,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 13,
              ),
            ),
          ),
          const Text(': '),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }

  void _showFilterDialog(BuildContext context) {
    final provider = context.read<GuruProvider>();

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: const Text('Filter Data Guru'),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'Mata Pelajaran',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: [
                    'Semua',
                    'Matematika',
                    'Bahasa Indonesia',
                    'Bahasa Inggris',
                    'IPA',
                    'IPS',
                    'PKN',
                    'Seni Budaya',
                    'PJOK',
                    'Prakarya',
                    'Agama Islam',
                  ].map((mapel) {
                    return FilterChip(
                      label: Text(mapel),
                      selected: provider.filterMataPelajaran == mapel,
                      onSelected: (selected) {
                        setState(() {
                          provider.setFilterMataPelajaran(mapel);
                        });
                      },
                    );
                  }).toList(),
                ),
                const SizedBox(height: 16),
                const Text(
                  'Status',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: ['Semua', 'Aktif', 'Cuti', 'Pensiun'].map((status) {
                    return FilterChip(
                      label: Text(status),
                      selected: provider.filterStatus == status,
                      onSelected: (selected) {
                        setState(() {
                          provider.setFilterStatus(status);
                        });
                      },
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                provider.clearFilters();
                Navigator.pop(context);
              },
              child: const Text('Reset'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Terapkan'),
            ),
          ],
        ),
      ),
    );
  }

  void _showDeleteConfirmation(BuildContext context, GuruModel guru) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Konfirmasi Hapus'),
        content: Text('Apakah Anda yakin ingin menghapus data guru "${guru.nama}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context);
              final success = await context.read<GuruProvider>().deleteGuru(guru.id);
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      success
                          ? 'Data guru berhasil dihapus'
                          : 'Gagal menghapus data guru',
                    ),
                    backgroundColor: success ? Colors.green : Colors.red,
                  ),
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
            ),
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
  }
}