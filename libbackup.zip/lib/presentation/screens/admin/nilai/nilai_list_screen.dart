//C:\Users\MSITHIN\monitoring_akademik\lib\presentation\screens\admin\nilai\nilai_list_screen.dart
import 'package:flutter/material.dart';
import 'package:monitoring_akademik/core/constants/color_constants.dart';
import 'package:monitoring_akademik/presentation/providers/nilai_provider.dart';
import 'package:monitoring_akademik/presentation/widgets/nilai_card.dart';
import 'package:monitoring_akademik/data/models/nilai_model.dart'; // ✅ TAMBAH INI
import 'package:provider/provider.dart';
import 'nilai_edit_screen.dart';
import 'package:monitoring_akademik/data/services/nilai_export_service.dart';

class NilaiListScreen extends StatefulWidget {
  const NilaiListScreen({Key? key}) : super(key: key);

  @override
  State<NilaiListScreen> createState() => _NilaiListScreenState();
}

class _NilaiListScreenState extends State<NilaiListScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _selectedKelas = 'Semua';
  String _selectedMapel = 'Semua';

  // List kelas dan mata pelajaran
  final List<String> _kelasList = [
    'Semua',
    '7A',
    '7B',
    '7C',
    '7D',
    '8A',
    '8B',
    '8C',
    '8D',
    '9A',
    '9B',
    '9C',
    '9D',
  ];

  final List<String> _mapelList = [
    'Semua',
    'Matematika',
    'Bahasa Indonesia',
    'Bahasa Inggris',
    'IPA',
    'IPS',
    'PKN',
    'Seni Budaya',
    'PJOK',
    'Prakarya',
  ];

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: const Text('Lihat & Edit Nilai'),
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        actions: [
          // Export Menu
          PopupMenuButton<String>(
            icon: const Icon(Icons.download),
            onSelected: _handleExport, // ✅ INI SUDAH BENAR
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'excel',
                child: Row(
                  children: [
                    Icon(Icons.table_chart, color: Colors.green),
                    SizedBox(width: 8),
                    Text('Export ke Excel'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'pdf',
                child: Row(
                  children: [
                    Icon(Icons.picture_as_pdf, color: Colors.red),
                    SizedBox(width: 8),
                    Text('Export ke PDF'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'print',
                child: Row(
                  children: [
                    Icon(Icons.print, color: Colors.blue),
                    SizedBox(width: 8),
                    Text('Cetak Nilai'),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          // Filter Section
          Container(
            color: Colors.white,
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                // Search Bar
                TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    hintText: 'Cari nama siswa...',
                    prefixIcon: const Icon(Icons.search),
                    suffixIcon: _searchController.text.isNotEmpty
                        ? IconButton(
                            icon: const Icon(Icons.clear),
                            onPressed: () {
                              _searchController.clear();
                              _applyFilters();
                            },
                          )
                        : null,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 12,
                    ),
                  ),
                  onChanged: (value) => _applyFilters(),
                ),

                const SizedBox(height: 12),

                // Filter Dropdowns
                Row(
                  children: [
                    // Filter Kelas
                    Expanded(
                      child: DropdownButtonFormField<String>(
                        value: _selectedKelas,
                        decoration: InputDecoration(
                          labelText: 'Kelas',
                          prefixIcon: const Icon(Icons.class_),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 8,
                          ),
                        ),
                        items: _kelasList.map((kelas) {
                          return DropdownMenuItem(
                            value: kelas,
                            child: Text(kelas),
                          );
                        }).toList(),
                        onChanged: (value) {
                          setState(() {
                            _selectedKelas = value!;
                          });
                          _applyFilters();
                        },
                      ),
                    ),

                    const SizedBox(width: 12),

                    // Filter Mata Pelajaran
                    Expanded(
                      child: DropdownButtonFormField<String>(
                        value: _selectedMapel,
                        decoration: InputDecoration(
                          labelText: 'Mata Pelajaran',
                          prefixIcon: const Icon(Icons.book),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 8,
                          ),
                        ),
                        items: _mapelList.map((mapel) {
                          return DropdownMenuItem(
                            value: mapel,
                            child: Text(mapel, overflow: TextOverflow.ellipsis),
                          );
                        }).toList(),
                        onChanged: (value) {
                          setState(() {
                            _selectedMapel = value!;
                          });
                          _applyFilters();
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // Nilai List
          Expanded(
            child: Consumer<NilaiProvider>(
              builder: (context, nilaiProvider, child) {
                final filteredNilai = _getFilteredNilai(nilaiProvider);

                if (nilaiProvider.isLoading) {
                  return const Center(child: CircularProgressIndicator());
                }

                if (filteredNilai.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.assessment_outlined,
                          size: 80,
                          color: Colors.grey[400],
                        ),
                        const SizedBox(height: 16),
                        Text(
                          'Belum ada data nilai',
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey[600],
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Coba ubah filter atau tambah data nilai',
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey[500],
                          ),
                        ),
                      ],
                    ),
                  );
                }

                return RefreshIndicator(
                  onRefresh: () async {
                    // Refresh data
                    setState(() {});
                  },
                  child: ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: filteredNilai.length,
                    itemBuilder: (context, index) {
                      final nilai = filteredNilai[index];
                      return NilaiCard(
                        nilai: nilai,
                        onEdit: () => _editNilai(nilai),
                        onDelete: () => _deleteNilai(nilai),
                      );
                    },
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _applyFilters() {
    setState(() {});
  }

  List<dynamic> _getFilteredNilai(NilaiProvider provider) {
    var filtered = provider.getAllNilai();

    // Filter by search query
    if (_searchController.text.isNotEmpty) {
      filtered = filtered.where((nilai) {
        return nilai.namaSiswa.toLowerCase().contains(
          _searchController.text.toLowerCase(),
        );
      }).toList();
    }

    // Filter by kelas
    if (_selectedKelas != 'Semua') {
      filtered = filtered.where((nilai) {
        return nilai.kelas == _selectedKelas;
      }).toList();
    }

    // Filter by mata pelajaran
    if (_selectedMapel != 'Semua') {
      filtered = filtered.where((nilai) {
        return nilai.mataPelajaran == _selectedMapel;
      }).toList();
    }

    return filtered;
  }

  void _editNilai(dynamic nilai) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => NilaiEditScreen(nilai: nilai)),
    );
  }

  void _deleteNilai(dynamic nilai) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Hapus Nilai'),
        content: Text(
          'Apakah Anda yakin ingin menghapus nilai ${nilai.mataPelajaran} untuk ${nilai.namaSiswa}?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () async {
              final provider = Provider.of<NilaiProvider>(
                context,
                listen: false,
              );
              final success = await provider.deleteNilai(nilai.id);

              if (mounted) {
                Navigator.pop(context);

                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      success
                          ? 'Nilai berhasil dihapus'
                          : 'Gagal menghapus nilai',
                    ),
                    backgroundColor: success ? Colors.green : Colors.red,
                  ),
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
  }

  // ✅ METHOD YANG DIPERBAIKI - TAMBAH async DAN await
  Future<void> _handleExport(String type) async {
    final provider = Provider.of<NilaiProvider>(context, listen: false);
    final filteredNilai = _getFilteredNilai(provider);

    // ✅ Check if data is empty
    if (filteredNilai.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('⚠️ Tidak ada data untuk diekspor'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    switch (type) {
      case 'excel':
        await _exportToExcel(filteredNilai);
        break;
      case 'pdf':
        await _exportToPdf(filteredNilai);
        break;
      case 'print':
        await _printNilai(filteredNilai);
        break;
    }
  }

  // ✅ EXPORT TO EXCEL (LENGKAP)
  Future<void> _exportToExcel(List<dynamic> data) async {
    try {
      // Show loading
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => const Center(
          child: CircularProgressIndicator(),
        ),
      );

      await NilaiExportService.exportToExcel(data.cast<NilaiModel>());

      if (mounted) {
        Navigator.pop(context); // Close loading

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('✅ Data berhasil diekspor ke Excel'),
            backgroundColor: Colors.green,
            duration: Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        Navigator.pop(context); // Close loading

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('❌ Gagal export Excel: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  // ✅ EXPORT TO PDF (LENGKAP)
  Future<void> _exportToPdf(List<dynamic> data) async {
    try {
      // Show loading
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => const Center(
          child: CircularProgressIndicator(),
        ),
      );

      await NilaiExportService.exportToPdf(data.cast<NilaiModel>());

      if (mounted) {
        Navigator.pop(context); // Close loading

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('✅ Data berhasil diekspor ke PDF'),
            backgroundColor: Colors.green,
            duration: Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        Navigator.pop(context); // Close loading

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('❌ Gagal export PDF: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  // ✅ PRINT (LENGKAP)
  Future<void> _printNilai(List<dynamic> data) async {
    try {
      await NilaiExportService.printNilai(data.cast<NilaiModel>());
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('❌ Gagal membuka print preview: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }
}