class SiswaEntity {
  final String id;
  final String nis;
  final String nisn;
  final String nama;
  final String jenisKelamin; // L atau P
  final String tempatLahir;
  final DateTime tanggalLahir;
  final String agama;
  final String alamat;
  final String namaAyah;
  final String namaIbu;
  final String noTelpOrangTua;
  final String kelas; // Contoh: "7A", "8B", "9C"
  final String tahunMasuk;
  final String status; // "Aktif", "Lulus", "Mutasi Keluar"
  final DateTime? createdAt;
  final DateTime? updatedAt;

  SiswaEntity({
    required this.id,
    required this.nis,
    required this.nisn,
    required this.nama,
    required this.jenisKelamin,
    required this.tempatLahir,
    required this.tanggalLahir,
    required this.agama,
    required this.alamat,
    required this.namaAyah,
    required this.namaIbu,
    required this.noTelpOrangTua,
    required this.kelas,
    required this.tahunMasuk,
    required this.status,
    this.createdAt,
    this.updatedAt,
  });

  // Helper untuk mendapatkan umur
  int get umur {
    final now = DateTime.now();
    int age = now.year - tanggalLahir.year;
    if (now.month < tanggalLahir.month ||
        (now.month == tanggalLahir.month && now.day < tanggalLahir.day)) {
      age--;
    }
    return age;
  }

  // Helper untuk format tanggal lahir
  String get tanggalLahirFormatted {
    return '${tanggalLahir.day.toString().padLeft(2, '0')}-'
        '${tanggalLahir.month.toString().padLeft(2, '0')}-'
        '${tanggalLahir.year}';
  }
}