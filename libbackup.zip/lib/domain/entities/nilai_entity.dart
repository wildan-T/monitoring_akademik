//C:\Users\MSITHIN\monitoring_akademik\lib\domain\entities\nilai_entity.dart
class NilaiEntity {
  final String id;
  final String siswaId;
  final String namaSiswa; // ✅ TAMBAH
  final String guruId;
  final String kelasId;
  final String kelas; // ✅ TAMBAH (untuk display, misal "7A")
  final String mataPelajaran;
  final double? nilaiTugas;
  final double? nilaiUH;
  final double? nilaiUTS;
  final double? nilaiUAS;
  final double? nilaiPraktik;
  final String? nilaiSikap; // A, B, C, D
  final bool isFinalized; // Sudah difinalisasi wali kelas atau belum
  final DateTime? finalizedAt;
  final String? finalizedBy; // ID wali kelas yang finalisasi
  final DateTime? createdAt;
  final DateTime? updatedAt;

  NilaiEntity({
    required this.id,
    required this.siswaId,
    required this.namaSiswa, // ✅ TAMBAH
    required this.guruId,
    required this.kelasId,
    required this.kelas, // ✅ TAMBAH
    required this.mataPelajaran,
    this.nilaiTugas,
    this.nilaiUH,
    this.nilaiUTS,
    this.nilaiUAS,
    this.nilaiPraktik,
    this.nilaiSikap,
    this.isFinalized = false,
    this.finalizedAt,
    this.finalizedBy,
    this.createdAt,
    this.updatedAt,
  });

  // Helper untuk cek apakah nilai sudah lengkap
  bool get isComplete {
    return nilaiTugas != null &&
        nilaiUH != null &&
        nilaiUTS != null &&
        nilaiUAS != null &&
        nilaiSikap != null; // ✅ UPDATE: praktik optional untuk mapel tertentu
  }

  // Helper untuk hitung nilai akhir (rata-rata tertimbang)
  // Bobot: Tugas 20%, UH 30%, UTS 20%, UAS 30%
  // Jika ada praktik: Tugas 15%, UH 25%, UTS 20%, UAS 25%, Praktik 15%
  double? get nilaiAkhir {
    if (nilaiTugas == null || nilaiUH == null || nilaiUTS == null || nilaiUAS == null) {
      return null;
    }

    if (nilaiPraktik != null) {
      // Dengan praktik
      return (nilaiTugas! * 0.15) +
          (nilaiUH! * 0.25) +
          (nilaiUTS! * 0.20) +
          (nilaiUAS! * 0.25) +
          (nilaiPraktik! * 0.15);
    } else {
      // Tanpa praktik
      return (nilaiTugas! * 0.20) +
          (nilaiUH! * 0.30) +
          (nilaiUTS! * 0.20) +
          (nilaiUAS! * 0.30);
    }
  }

  // Helper untuk konversi nilai akhir ke huruf
  String? get nilaiHuruf {
    if (nilaiAkhir == null) return null;

    if (nilaiAkhir! >= 90) return 'A';
    if (nilaiAkhir! >= 80) return 'B';
    if (nilaiAkhir! >= 70) return 'C';
    if (nilaiAkhir! >= 60) return 'D';
    return 'E';
  }

  // Helper untuk predikat
  String? get predikat {
    if (nilaiHuruf == null) return null;

    switch (nilaiHuruf) {
      case 'A':
        return 'Sangat Baik';
      case 'B':
        return 'Baik';
      case 'C':
        return 'Cukup';
      case 'D':
        return 'Kurang';
      case 'E':
        return 'Sangat Kurang';
      default:
        return '-';
    }
  }
}