class UserEntity {
  final String id;
  final String username;
  final String name;
  final String role;
  final String? email;
  final String? phone;

  UserEntity({
    required this.id,
    required this.username,
    required this.name,
    required this.role,
    this.email,
    this.phone,
  });
}