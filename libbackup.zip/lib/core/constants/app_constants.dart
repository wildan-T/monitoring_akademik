//C:\Users\MSITHIN\monitoring_akademik\lib\core\constants\app_constants.dart
class AppConstants {
  // App Info
  static const String appName = 'Monitoring Akademik';
  static const String schoolName = 'SMPN 20 Kota Tangerang';
  static const String appVersion = '1.0.0';

  // Roles
  static const String roleAdmin = 'admin';
  static const String roleGuru = 'guru';
  static const String roleWaliMurid = 'wali_murid';

  // Dummy Users
  static final Map<String, dynamic> dummyAdmin = {
    'id': 'admin-1',
    'username': 'admin',
    'password': 'admin123',
    'name': 'Administrator',
    'email': 'admin@smpn20.sch.id',
    'role': roleAdmin,
  };

  static final Map<String, dynamic> dummyGuru = {
    'id': '1', // ID Heni dari GuruProvider
    'username': 'guru',
    'password': 'guru123',
    'name': 'Heni Rizki Amalia',
    'email': 'heni.rizki@smpn20.sch.id',
    'role': roleGuru,
  };

// ✅ GURU 2: Budi (Wali Kelas 7B)
    static final Map<String, dynamic> dummyGuru2 = {
    'id': '2', // ID Heni dari GuruProvider
    'username': 'guru2',
    'password': 'guru123',
    'name': 'Budi Prasetyo',
    'email': 'heni.rizki@smpn20.sch.id',
    'role': roleGuru,
  };

    // ✅ GURU 3: Siti (Guru Mapel, BUKAN Wali Kelas)
  static const Map<String, dynamic> dummyGuru3 = {
    'id': '3',
    'username': 'guru3',
    'password': 'guru123',
    'name': 'Siti Aminah',
    'role': 'guru',
  };


  static final Map<String, dynamic> dummyWaliMurid = {
    'id': 'wali-1',
    'username': 'wali',
    'password': 'wali123',
    'name': 'Budi Santoso',
    'email': 'budi.santoso@gmail.com',
    'role': roleWaliMurid,
  };

  // Storage Keys
  static const String keyIsLoggedIn = 'is_logged_in';
  static const String keyUserId = 'user_id';
  static const String keyUserName = 'user_name';
  static const String keyUserEmail = 'user_email';
  static const String keyUserRole = 'user_role';
}