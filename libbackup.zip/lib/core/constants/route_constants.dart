class RouteConstants {
  // Root
  static const String splash = '/';
  static const String login = '/login';
  
  // Admin Routes
  static const String adminDashboard = '/admin-dashboard';
  static const String kelolaUser = '/admin/kelola-user';
  static const String kelolaSiswa = '/admin/kelola-siswa';
  static const String kelolaGuru = '/admin/kelola-guru';
  static const String kelolaSekolah = '/admin/kelola-sekolah';
  static const String importData = '/admin/import-data';
  
  // Admin Routes - Siswa
static const String kelolaSiswaList = '/admin/kelola-siswa/list';
static const String kelolaSiswaAdd = '/admin/kelola-siswa/add';
static const String kelolaSiswaEdit = '/admin/kelola-siswa/edit';
  
  // Guru Routes
  static const String guruDashboard = '/guru-dashboard';
  static const String inputNilai = '/guru/input-nilai';
  static const String dataSiswa = '/guru/data-siswa';
  static const String rekapNilai = '/guru/rekap-nilai';
  
  // Wali Murid Routes
  static const String waliMuridDashboard = '/wali-murid-dashboard';
  static const String nilaiAnak = '/wali-murid/nilai-anak';
  static const String absensi = '/wali-murid/absensi';
  static const String jadwal = '/wali-murid/jadwal';
  static const String pengumuman = '/wali-murid/pengumuman';
  static const String raport = '/wali-murid/raport';
  static const String profilAnak = '/wali-murid/profil-anak';
  static const String pengaturan = '/wali-murid/pengaturan';
}