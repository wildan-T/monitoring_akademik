//C:\Users\MSITHIN\monitoring_akademik\lib\data\models\nilai_model.dart
import '../../domain/entities/nilai_entity.dart';

class NilaiModel extends NilaiEntity {
  NilaiModel({
    required super.id,
    required super.siswaId,
    required super.namaSiswa, // ✅ TAMBAH
    required super.guruId,
    required super.kelasId,
    required super.kelas, // ✅ TAMBAH
    required super.mataPelajaran,
    super.nilaiTugas,
    super.nilaiUH,
    super.nilaiUTS,
    super.nilaiUAS,
    super.nilaiPraktik,
    super.nilaiSikap,
    super.isFinalized,
    super.finalizedAt,
    super.finalizedBy,
    super.createdAt,
    super.updatedAt,
  });

  // From JSON
  factory NilaiModel.fromJson(Map<String, dynamic> json) {
    return NilaiModel(
      id: json['id']?.toString() ?? '',
      siswaId: json['siswa_id']?.toString() ?? '',
      namaSiswa: json['nama_siswa']?.toString() ?? '', // ✅ TAMBAH
      guruId: json['guru_id']?.toString() ?? '',
      kelasId: json['kelas_id']?.toString() ?? '',
      kelas: json['kelas']?.toString() ?? '', // ✅ TAMBAH
      mataPelajaran: json['mata_pelajaran']?.toString() ?? '',
      nilaiTugas: json['nilai_tugas'] != null
          ? double.tryParse(json['nilai_tugas'].toString())
          : null,
      nilaiUH: json['nilai_uh'] != null
          ? double.tryParse(json['nilai_uh'].toString())
          : null,
      nilaiUTS: json['nilai_uts'] != null
          ? double.tryParse(json['nilai_uts'].toString())
          : null,
      nilaiUAS: json['nilai_uas'] != null
          ? double.tryParse(json['nilai_uas'].toString())
          : null,
      nilaiPraktik: json['nilai_praktik'] != null
          ? double.tryParse(json['nilai_praktik'].toString())
          : null,
      nilaiSikap: json['nilai_sikap']?.toString(),
      isFinalized: json['is_finalized'] == true || json['is_finalized'] == 1,
      finalizedAt: json['finalized_at'] != null
          ? DateTime.parse(json['finalized_at'])
          : null,
      finalizedBy: json['finalized_by']?.toString(),
      createdAt: json['created_at'] != null
          ? DateTime.parse(json['created_at'])
          : null,
      updatedAt: json['updated_at'] != null
          ? DateTime.parse(json['updated_at'])
          : null,
    );
  }

  // To JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'siswa_id': siswaId,
      'nama_siswa': namaSiswa, // ✅ TAMBAH
      'guru_id': guruId,
      'kelas_id': kelasId,
      'kelas': kelas, // ✅ TAMBAH
      'mata_pelajaran': mataPelajaran,
      'nilai_tugas': nilaiTugas,
      'nilai_uh': nilaiUH,
      'nilai_uts': nilaiUTS,
      'nilai_uas': nilaiUAS,
      'nilai_praktik': nilaiPraktik,
      'nilai_sikap': nilaiSikap,
      'is_finalized': isFinalized,
      'finalized_at': finalizedAt?.toIso8601String(),
      'finalized_by': finalizedBy,
      'created_at': createdAt?.toIso8601String(),
      'updated_at': updatedAt?.toIso8601String(),
    };
  }

  // Copy with
  NilaiModel copyWith({
    String? id,
    String? siswaId,
    String? namaSiswa, // ✅ TAMBAH
    String? guruId,
    String? kelasId,
    String? kelas, // ✅ TAMBAH
    String? mataPelajaran,
    double? nilaiTugas,
    double? nilaiUH,
    double? nilaiUTS,
    double? nilaiUAS,
    double? nilaiPraktik,
    String? nilaiSikap,
    bool? isFinalized,
    DateTime? finalizedAt,
    String? finalizedBy,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return NilaiModel(
      id: id ?? this.id,
      siswaId: siswaId ?? this.siswaId,
      namaSiswa: namaSiswa ?? this.namaSiswa, // ✅ TAMBAH
      guruId: guruId ?? this.guruId,
      kelasId: kelasId ?? this.kelasId,
      kelas: kelas ?? this.kelas, // ✅ TAMBAH
      mataPelajaran: mataPelajaran ?? this.mataPelajaran,
      nilaiTugas: nilaiTugas ?? this.nilaiTugas,
      nilaiUH: nilaiUH ?? this.nilaiUH,
      nilaiUTS: nilaiUTS ?? this.nilaiUTS,
      nilaiUAS: nilaiUAS ?? this.nilaiUAS,
      nilaiPraktik: nilaiPraktik ?? this.nilaiPraktik,
      nilaiSikap: nilaiSikap ?? this.nilaiSikap,
      isFinalized: isFinalized ?? this.isFinalized,
      finalizedAt: finalizedAt ?? this.finalizedAt,
      finalizedBy: finalizedBy ?? this.finalizedBy,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}