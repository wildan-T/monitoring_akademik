//C:\Users\MSITHIN\monitoring_akademik\lib\data\models\guru_model.dart
import 'package:intl/intl.dart';

class GuruModel {
  final String id;
  final String nama;
  final String nip;
  final String? nuptk; // ✅ TAMBAH FIELD NUPTK
  final String email;
  final String jenisKelamin; // 'L' atau 'P'
  final String tempatLahir;
  final DateTime tanggalLahir;
  final String agama;
  final String alamat;
  final String noTelp;
  final String pendidikanTerakhir;
  final String? waliKelas; // Kelas yang dipegang jika wali kelas (misal: "7A", "8B")
  final List<String> mataPelajaran; // List mata pelajaran yang diajar
  final String status; // 'Aktif', 'Cuti', 'Non-Aktif'
  final DateTime createdAt;
  final DateTime? updatedAt;

  GuruModel({
    required this.id,
    required this.nama,
    required this.nip,
    this.nuptk, // ✅ TAMBAH DI CONSTRUCTOR
    required this.email,
    required this.jenisKelamin,
    required this.tempatLahir,
    required this.tanggalLahir,
    required this.agama,
    required this.alamat,
    required this.noTelp,
    required this.pendidikanTerakhir,
    this.waliKelas,
    required this.mataPelajaran,
    required this.status,
    required this.createdAt,
    this.updatedAt,
  });

  // ✅ GETTER: Cek apakah wali kelas
  bool get isWaliKelas => waliKelas != null && waliKelas!.isNotEmpty;

  // ✅ GETTER: Format mata pelajaran jadi string
  String get mataPelajaranString => mataPelajaran.join(', ');

  // ✅ GETTER: Format tanggal lahir
  String get tanggalLahirFormatted {
    return DateFormat('dd MMMM yyyy', 'id_ID').format(tanggalLahir);
  }

  // ✅ GETTER: Hitung umur
  int get umur {
    final now = DateTime.now();
    int age = now.year - tanggalLahir.year;
    if (now.month < tanggalLahir.month ||
        (now.month == tanggalLahir.month && now.day < tanggalLahir.day)) {
      age--;
    }
    return age;
  }

  // Factory from JSON
  factory GuruModel.fromJson(Map<String, dynamic> json) {
    return GuruModel(
      id: json['id'] as String,
      nama: json['nama'] as String,
      nip: json['nip'] as String,
      nuptk: json['nuptk'] as String?,
      email: json['email'] as String,
      jenisKelamin: json['jenis_kelamin'] as String,
      tempatLahir: json['tempat_lahir'] as String,
      tanggalLahir: DateTime.parse(json['tanggal_lahir'] as String),
      agama: json['agama'] as String,
      alamat: json['alamat'] as String,
      noTelp: json['no_telp'] as String,
      pendidikanTerakhir: json['pendidikan_terakhir'] as String,
      waliKelas: json['wali_kelas'] as String?,
      mataPelajaran: List<String>.from(json['mata_pelajaran'] as List),
      status: json['status'] as String,
      createdAt: DateTime.parse(json['created_at'] as String),
      updatedAt: json['updated_at'] != null
          ? DateTime.parse(json['updated_at'] as String)
          : null,
    );
  }

  // To JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'nama': nama,
      'nip': nip,
      'nuptk': nuptk,
      'email': email,
      'jenis_kelamin': jenisKelamin,
      'tempat_lahir': tempatLahir,
      'tanggal_lahir': tanggalLahir.toIso8601String(),
      'agama': agama,
      'alamat': alamat,
      'no_telp': noTelp,
      'pendidikan_terakhir': pendidikanTerakhir,
      'wali_kelas': waliKelas,
      'mata_pelajaran': mataPelajaran,
      'status': status,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt?.toIso8601String(),
    };
  }

  // CopyWith
  GuruModel copyWith({
    String? id,
    String? nama,
    String? nip,
    String? nuptk,
    String? email,
    String? jenisKelamin,
    String? tempatLahir,
    DateTime? tanggalLahir,
    String? agama,
    String? alamat,
    String? noTelp,
    String? pendidikanTerakhir,
    String? waliKelas,
    List<String>? mataPelajaran,
    String? status,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return GuruModel(
      id: id ?? this.id,
      nama: nama ?? this.nama,
      nip: nip ?? this.nip,
      nuptk: nuptk ?? this.nuptk,
      email: email ?? this.email,
      jenisKelamin: jenisKelamin ?? this.jenisKelamin,
      tempatLahir: tempatLahir ?? this.tempatLahir,
      tanggalLahir: tanggalLahir ?? this.tanggalLahir,
      agama: agama ?? this.agama,
      alamat: alamat ?? this.alamat,
      noTelp: noTelp ?? this.noTelp,
      pendidikanTerakhir: pendidikanTerakhir ?? this.pendidikanTerakhir,
      waliKelas: waliKelas ?? this.waliKelas,
      mataPelajaran: mataPelajaran ?? this.mataPelajaran,
      status: status ?? this.status,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}