class AbsensiModel {
  final String id;
  final String siswaId;
  final String guruId;
  final String kelas;
  final DateTime tanggal;
  final AbsensiStatus status;
  final String? keterangan;
  final DateTime createdAt;
  final DateTime? updatedAt;

  AbsensiModel({
    required this.id,
    required this.siswaId,
    required this.guruId,
    required this.kelas,
    required this.tanggal,
    required this.status,
    this.keterangan,
    required this.createdAt,
    this.updatedAt,
  });

  // Copy with
  AbsensiModel copyWith({
    String? id,
    String? siswaId,
    String? guruId,
    String? kelas,
    DateTime? tanggal,
    AbsensiStatus? status,
    String? keterangan,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return AbsensiModel(
      id: id ?? this.id,
      siswaId: siswaId ?? this.siswaId,
      guruId: guruId ?? this.guruId,
      kelas: kelas ?? this.kelas,
      tanggal: tanggal ?? this.tanggal,
      status: status ?? this.status,
      keterangan: keterangan ?? this.keterangan,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  // From JSON
  factory AbsensiModel.fromJson(Map<String, dynamic> json) {
    return AbsensiModel(
      id: json['id'] as String,
      siswaId: json['siswa_id'] as String,
      guruId: json['guru_id'] as String,
      kelas: json['kelas'] as String,
      tanggal: DateTime.parse(json['tanggal'] as String),
      status: AbsensiStatus.values.firstWhere(
        (e) => e.toString() == 'AbsensiStatus.${json['status']}',
      ),
      keterangan: json['keterangan'] as String?,
      createdAt: DateTime.parse(json['created_at'] as String),
      updatedAt: json['updated_at'] != null
          ? DateTime.parse(json['updated_at'] as String)
          : null,
    );
  }

  // To JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'siswa_id': siswaId,
      'guru_id': guruId,
      'kelas': kelas,
      'tanggal': tanggal.toIso8601String(),
      'status': status.toString().split('.').last,
      'keterangan': keterangan,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt?.toIso8601String(),
    };
  }

  // Getter untuk label status
  String get statusLabel {
    switch (status) {
      case AbsensiStatus.hadir:
        return 'Hadir';
      case AbsensiStatus.izin:
        return 'Izin';
      case AbsensiStatus.sakit:
        return 'Sakit';
      case AbsensiStatus.alpha:
        return 'Alpha';
    }
  }

  // Getter untuk warna status
  String get statusColor {
    switch (status) {
      case AbsensiStatus.hadir:
        return '#4CAF50'; // Green
      case AbsensiStatus.izin:
        return '#FF9800'; // Orange
      case AbsensiStatus.sakit:
        return '#2196F3'; // Blue
      case AbsensiStatus.alpha:
        return '#F44336'; // Red
    }
  }
}

// Enum untuk status absensi
enum AbsensiStatus {
  hadir,
  izin,
  sakit,
  alpha,
}