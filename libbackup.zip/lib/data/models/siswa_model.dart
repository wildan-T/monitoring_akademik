//C:\Users\MSITHIN\monitoring_akademik\lib\data\models\siswa_model.dart
import '../../domain/entities/siswa_entity.dart';

class SiswaModel extends SiswaEntity {
  SiswaModel({
    required super.id,
    required super.nis,
    required super.nisn,
    required super.nama,
    required super.jenisKelamin,
    required super.tempatLahir,
    required super.tanggalLahir,
    required super.agama,
    required super.alamat,
    required super.namaAyah,
    required super.namaIbu,
    required super.noTelpOrangTua,
    required super.kelas,
    required super.tahunMasuk,
    required super.status,
    super.createdAt,
    super.updatedAt,
  });

  // From JSON (untuk parsing dari API nanti)
  factory SiswaModel.fromJson(Map<String, dynamic> json) {
    return SiswaModel(
      id: json['id']?.toString() ?? '',
      nis: json['nis']?.toString() ?? '',
      nisn: json['nisn']?.toString() ?? '',
      nama: json['nama']?.toString() ?? '',
      jenisKelamin: json['jenis_kelamin']?.toString() ?? '',
      tempatLahir: json['tempat_lahir']?.toString() ?? '',
      tanggalLahir: json['tanggal_lahir'] != null
          ? DateTime.parse(json['tanggal_lahir'])
          : DateTime.now(),
      agama: json['agama']?.toString() ?? '',
      alamat: json['alamat']?.toString() ?? '',
      namaAyah: json['nama_ayah']?.toString() ?? '',
      namaIbu: json['nama_ibu']?.toString() ?? '',
      noTelpOrangTua: json['no_telp_orang_tua']?.toString() ?? '',
      kelas: json['kelas']?.toString() ?? '',
      tahunMasuk: json['tahun_masuk']?.toString() ?? '',
      status: json['status']?.toString() ?? 'Aktif',
      createdAt: json['created_at'] != null
          ? DateTime.parse(json['created_at'])
          : null,
      updatedAt: json['updated_at'] != null
          ? DateTime.parse(json['updated_at'])
          : null,
    );
  }

  // To JSON (untuk kirim ke API nanti)
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'nis': nis,
      'nisn': nisn,
      'nama': nama,
      'jenis_kelamin': jenisKelamin,
      'tempat_lahir': tempatLahir,
      'tanggal_lahir': tanggalLahir.toIso8601String(),
      'agama': agama,
      'alamat': alamat,
      'nama_ayah': namaAyah,
      'nama_ibu': namaIbu,
      'no_telp_orang_tua': noTelpOrangTua,
      'kelas': kelas,
      'tahun_masuk': tahunMasuk,
      'status': status,
      'created_at': createdAt?.toIso8601String(),
      'updated_at': updatedAt?.toIso8601String(),
    };
  }

  // Copy with (untuk update data)
  SiswaModel copyWith({
    String? id,
    String? nis,
    String? nisn,
    String? nama,
    String? jenisKelamin,
    String? tempatLahir,
    DateTime? tanggalLahir,
    String? agama,
    String? alamat,
    String? namaAyah,
    String? namaIbu,
    String? noTelpOrangTua,
    String? kelas,
    String? tahunMasuk,
    String? status,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return SiswaModel(
      id: id ?? this.id,
      nis: nis ?? this.nis,
      nisn: nisn ?? this.nisn,
      nama: nama ?? this.nama,
      jenisKelamin: jenisKelamin ?? this.jenisKelamin,
      tempatLahir: tempatLahir ?? this.tempatLahir,
      tanggalLahir: tanggalLahir ?? this.tanggalLahir,
      agama: agama ?? this.agama,
      alamat: alamat ?? this.alamat,
      namaAyah: namaAyah ?? this.namaAyah,
      namaIbu: namaIbu ?? this.namaIbu,
      noTelpOrangTua: noTelpOrangTua ?? this.noTelpOrangTua,
      kelas: kelas ?? this.kelas,
      tahunMasuk: tahunMasuk ?? this.tahunMasuk,
      status: status ?? this.status,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}