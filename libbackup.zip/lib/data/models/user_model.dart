//C:\Users\MSITHIN\monitoring_akademik\lib\data\models\user_model.dart
import '../../domain/entities/user_entity.dart';

class UserModel extends UserEntity {
  UserModel({
    required super.id,
    required super.username,
    required super.name,
    required super.role,
    super.email,
    super.phone,
  });

  // From JSON (nanti untuk parsing dari API)
  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'] ?? '',
      username: json['username'] ?? '',
      name: json['name'] ?? '',
      role: json['role'] ?? '',
      email: json['email'],
      phone: json['phone'],
    );
  }

  // To JSON (untuk kirim ke API)
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'username': username,
      'name': name,
      'role': role,
      'email': email,
      'phone': phone,
    };
  }
}