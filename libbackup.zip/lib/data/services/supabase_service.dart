import 'package:supabase_flutter/supabase_flutter.dart';

class SupabaseService {
  static final SupabaseClient client = Supabase.instance.client;
  
  // Auth
  static User? get currentUser => client.auth.currentUser;
  static Session? get currentSession => client.auth.currentSession;
  
  // Sign In
  static Future<AuthResponse> signIn(String email, String password) async {
    return await client.auth.signInWithPassword(
      email: email,
      password: password,
    );
  }
  
  // Sign Out
  static Future<void> signOut() async {
    await client.auth.signOut();
  }
  
  // Get current user profile
  static Future<Map<String, dynamic>?> getCurrentProfile() async {
    final userId = currentUser?.id;
    if (userId == null) return null;
    
    final response = await client
        .from('profiles')
        .select()
        .eq('id', userId)
        .single();
    
    return response;
  }
  
  // Tables
  static SupabaseQueryBuilder get profiles => client.from('profiles');
  static SupabaseQueryBuilder get sekolah => client.from('sekolah');
  static SupabaseQueryBuilder get guru => client.from('guru');
  static SupabaseQueryBuilder get pesertaDidik => client.from('peserta_didik');
  static SupabaseQueryBuilder get kelas => client.from('kelas');
  static SupabaseQueryBuilder get mataPelajaran => client.from('mata_pelajaran');
  static SupabaseQueryBuilder get tahunPelajaran => client.from('tahun_pelajaran');
  static SupabaseQueryBuilder get nilai => client.from('nilai');
  static SupabaseQueryBuilder get raport => client.from('raport');
  static SupabaseQueryBuilder get pengumuman => client.from('pengumuman');
}